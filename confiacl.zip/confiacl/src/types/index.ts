// Tipos compartidos de ConfiaCL - Alineados con schema SQL

export type UserRole = 'cliente' | 'tecnico' | 'admin'
export type SolicitudEstado = 'abierta' | 'visita_agendada' | 'en_proceso' | 'finalizada' | 'cancelada'
export type PropuestaEstado = 'pendiente' | 'aceptada' | 'rechazada'

// === USUARIOS ===
export interface User {
  id: string
  nombre_completo: string
  rut?: string
  telefono?: string
  rol: UserRole
  fecha_registro: string
  es_admin: boolean
  email: string
}

// === SOLICITUDES ===
export interface Solicitud {
  id: string
  cliente_id: string
  categoria_id: number
  titulo: string
  descripcion?: string
  estado: SolicitudEstado
  presupuesto_estimado?: number
  fecha_creacion: string
  comuna: string
  cliente?: User
  propuestas?: Propuesta[]
}

// === PROPUESTAS ===
export interface Propuesta {
  id: string
  solicitud_id: string
  tecnico_id: string
  mensaje: string
  precio_ofertado: number
  estado: PropuestaEstado
  fecha_creacion: string
  tecnico?: User
  solicitud?: Solicitud
}

// === NOTIFICACIONES ===
export interface Notification {
  id: string
  usuario_id: string
  titulo?: string
  mensaje: string
  leida: boolean
  fecha_creacion: string
  enlace?: string
}

// === MENSAJES ===
export interface Mensaje {
  id: string
  solicitud_id: string
  emisor_id: string
  contenido: string
  fecha_creacion: string
  emisor?: User
}

// === RESEÑAS ===
export interface Resena {
  id: string
  solicitud_id: string
  cliente_id: string
  tecnico_id: string
  puntuacion: number // 1-5
  comentario?: string
  fecha_creacion: string
  cliente?: User
  tecnico?: User
}

// === CATEGORIAS ===
export interface Categoria {
  id: number
  nombre: string
  icono_url?: string
}

// === PERFILES TECNICOS ===
export interface PerfilTecnico {
  usuario_id: string
  biografia?: string
  anos_experiencia: number
  certificado_sec: boolean
  foto_perfil_url?: string
  valor_visita: number
  verificado: boolean
  fecha_actualizacion: string
  certificado_sec_url?: string
  categoria_id?: number
  usuario?: User
}

// === API RESPONSES ===
export interface ApiResponse<T = any> {
  success: boolean
  data?: T
  error?: string
  message?: string
  errors?: Record<string, string>
}

export interface LoginRequest {
  email: string
  password: string
}

export interface LoginResponse {
  user: User
  token: string
}

export interface CreateSolicitudRequest {
  titulo: string
  descripcion: string
  categoria_id: number
  presupuesto_estimado?: number
  comuna: string
}

export interface CreatePropuestaRequest {
  solicitud_id: string
  precio_ofertado: number
  mensaje: string
}

export interface CreateResenaRequest {
  solicitud_id: string
  tecnico_id: string
  calificacion: number
  comentario: string
}

export interface CreateMensajeRequest {
  solicitud_id: string
  contenido: string
}
