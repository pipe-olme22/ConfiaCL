'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { API } from '@/lib/api-client'
import { Button, Card, Input } from '@/components/ui'
import { validarPresupuesto } from '@/lib/validaciones'

interface FormData {
  titulo: string
  descripcion: string
  categoria_id?: number
  comuna: string
  presupuesto_estimado?: number
}

interface FormErrors {
  titulo?: string
  descripcion?: string
  categoria_id?: string
  comuna?: string
  presupuesto_estimado?: string
}

const CATEGORIAS = [
  'Electricidad',
  'Gasfitería',
  'Pintura',
  'Carpintería',
  'Hogar General',
  'Reparación Electrodomésticos',
  'Aire Acondicionado',
  'Cerrajería',
  'Vidriería',
  'Limpieza',
  'Otros',
]

export default function NuevaSolicitud() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [step, setStep] = useState(1)
  const [errors, setErrors] = useState<FormErrors>({})
  const [form, setForm] = useState<FormData>({
    titulo: '',
    descripcion: '',
    categoria_id: undefined,
    comuna: '',
    presupuesto_estimado: undefined,
  })

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {}

    if (!form.titulo.trim() || form.titulo.length < 5) {
      newErrors.titulo = 'El título debe tener al menos 5 caracteres'
    }

    if (!form.descripcion.trim() || form.descripcion.length < 10) {
      newErrors.descripcion = 'La descripción debe tener al menos 10 caracteres'
    }

    if (!form.categoria_id) {
      newErrors.categoria_id = 'Debes seleccionar una categoría'
    }

    if (!form.comuna.trim()) {
      newErrors.comuna = 'La comuna es requerida'
    }

    if (form.presupuesto_estimado && form.presupuesto_estimado < 0) {
      newErrors.presupuesto_estimado = 'El presupuesto no puede ser negativo'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setLoading(true)

    const result = await API.createSolicitud(form)

    if (!result.success) {
      setErrors(result.errors || { presupuesto_estimado: result.error })
      setLoading(false)
      return
    }

    router.push('/mis-solicitudes-cliente')
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-black text-gray-900 mb-2">¿Qué necesitas solucionar?</h1>
          <p className="text-lg text-gray-600">
            Describe tu problema y los mejores técnicos de Talagante te contactarán con presupuestos.
          </p>
        </div>

        {/* Progress Indicator */}
        <div className="flex gap-2 mb-8">
          {[1, 2].map(s => (
            <div
              key={s}
              className={`h-2 flex-1 rounded-full transition-all ${
                s <= step ? 'bg-blue-600' : 'bg-gray-200'
              }`}
            />
          ))}
        </div>

        <form onSubmit={handleSubmit}>
          {/* PASO 1: Información básica */}
          {step === 1 && (
            <Card className="p-8 space-y-6">
              <div>
                <h2 className="text-2xl font-black text-gray-900 mb-6">Información Básica</h2>
              </div>

              <Input
                label="Título del problema"
                placeholder="Ej: Filtración en lavaplatos"
                value={form.titulo}
                onChange={e => setForm({ ...form, titulo: e.target.value })}
                error={errors.titulo}
                required
              />

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Categoría <span className="text-red-500">*</span>
                </label>
                <select
                  value={form.categoria_id || ''}
                  onChange={e => setForm({ ...form, categoria_id: e.target.value ? parseInt(e.target.value) : undefined })}
                  className={`w-full p-4 rounded-2xl bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white outline-none transition text-gray-900 ${
                    errors.categoria_id ? 'border-red-500 focus:border-red-500' : ''
                  }`}
                  required
                >
                  <option value="">Selecciona una categoría...</option>
                  {CATEGORIAS.map((cat, idx) => (
                    <option key={idx} value={idx + 1}>
                      {cat}
                    </option>
                  ))}
                </select>
                {errors.categoria_id && (
                  <p className="text-red-500 text-xs font-medium mt-1">{errors.categoria_id}</p>
                )}
              </div>

              <Input
                label="Comuna"
                placeholder="Ej: Talagante, sector San Juan"
                value={form.comuna}
                onChange={e => setForm({ ...form, comuna: e.target.value })}
                error={errors.comuna}
                required
              />

              <div className="flex gap-4 pt-4 border-t border-gray-100">
                <Button variant="secondary" size="lg" type="button" onClick={() => router.back()}>
                  ← Atrás
                </Button>
                <Button size="lg" onClick={() => setStep(2)}>
                  Siguiente →
                </Button>
              </div>
            </Card>
          )}

          {/* PASO 2: Descripción y presupuesto */}
          {step === 2 && (
            <Card className="p-8 space-y-6">
              <div>
                <h2 className="text-2xl font-black text-gray-900 mb-6">Descripción y Presupuesto</h2>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Descripción detallada <span className="text-red-500">*</span>
                </label>
                <textarea
                  placeholder="Describe el problema con detalles: qué es, cuándo comenzó, qué has notado..."
                  value={form.descripcion}
                  onChange={e => setForm({ ...form, descripcion: e.target.value })}
                  className={`w-full p-4 rounded-2xl bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white outline-none transition text-gray-900 h-32 resize-none ${
                    errors.descripcion ? 'border-red-500 focus:border-red-500' : ''
                  }`}
                  required
                />
                {errors.descripcion && (
                  <p className="text-red-500 text-xs font-medium mt-1">{errors.descripcion}</p>
                )}
              </div>

              <div className="bg-blue-50 border border-blue-100 p-4 rounded-2xl">
                <p className="text-sm text-blue-900 font-medium">
                  💡 Tip: Proporcionar un presupuesto estimado ayuda a los técnicos a dar respuestas más rápidas.
                </p>
              </div>

              <Input
                label="Presupuesto Estimado ($)"
                type="number"
                placeholder="Ej: 35000"
                value={form.presupuesto_estimado || ''}
                onChange={e =>
                  setForm({
                    ...form,
                    presupuesto_estimado: e.target.value ? parseInt(e.target.value) : undefined,
                  })
                }
              />
              {errors.presupuesto_estimado && (
                <p className="text-red-500 text-sm font-medium">{errors.presupuesto_estimado}</p>
              )}

              <div className="flex gap-4 pt-4 border-t border-gray-100">
                <Button variant="secondary" size="lg" onClick={() => setStep(1)}>
                  ← Anterior
                </Button>
                <Button size="lg" type="submit" isLoading={loading}>
                  {loading ? 'Publicando...' : ' Publicar Solicitud'}
                </Button>
              </div>
            </Card>
          )}
        </form>

        {/* Info Box */}
        <div className="mt-8 p-6 bg-blue-50 border border-blue-100 rounded-2xl text-center">
          <p className="text-sm text-blue-900 font-medium">
            ✓ Tu solicitud será visible para {CATEGORIAS.length} categorías de técnicos especializados en Talagante.
          </p>
        </div>
      </div>
    </div>
  )
}