import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar"; // 1. Importamos el componente

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ConfiaCL | Expertos de Confianza",
  description: "Marketplace de servicios técnicos en Talagante y alrededores.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="es" // Cambiado a español para mejor SEO local
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col bg-gray-50">
        {/* 2. Insertamos el Navbar arriba de los hijos (children) */}
        <Navbar />

        {/* 3. Envolvemos el children en un main con flex-grow 
               para que el contenido empuje hacia abajo si es necesario */}
        <main className="flex-grow">
          {children}
        </main>

        {/* Aquí podrías agregar un Footer en el futuro */}
      </body>
    </html>
  );
}
