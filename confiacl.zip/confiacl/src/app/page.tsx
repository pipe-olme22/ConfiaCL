'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { API } from '@/lib/api-client'
import type { User, Solicitud } from '@/types'

export default function LandingPage() {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [misSolicitudes, setMisSolicitudes] = useState<Solicitud[]>([])
  const router = useRouter()

  useEffect(() => {
    const loadData = async () => {
      // Verificar si hay token en localStorage
      const token = localStorage.getItem('auth_token')
      if (!token) {
        setLoading(false)
        return
      }

      // Obtener usuario actual
      const userResult = await API.getMe()
      
      if (userResult.success) {
        const userData = userResult.data as User
        setUser(userData)
        
        // Cargar solicitudes del usuario
        const solicitudesResult = await API.getMyRequestos()
        if (solicitudesResult.success) {
          setMisSolicitudes((solicitudesResult.data as any) || [])
        }
      } else {
        // Si el token es inválido, limpiar
        localStorage.removeItem('auth_token')
      }
      
      setLoading(false)
    }
    
    loadData()
  }, [])

  const handleLogout = async () => {
    await API.logout()
    localStorage.removeItem('auth_token')
    setUser(null)
    router.refresh()
  }

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans">
      
      {user ? (
        /* ============================================================
           VISTA: DASHBOARD DEL CLIENTE (USUARIO LOGEADO)
           ============================================================ */
        <main className="max-w-7xl mx-auto p-8 flex flex-col md:flex-row gap-8">
          
          {/* BARRA LATERAL - FUNCIONALIDADES CLIENTE */}
          <aside className="w-full md:w-64 space-y-4">
            <h2 className="text-xs font-black uppercase text-gray-400 tracking-widest mb-4">Gestión de Hogar</h2>
            <Link href="/nueva-solicitud-cliente" className="flex items-center gap-3 p-4 bg-blue-600 text-white rounded-2xl font-bold shadow-xl shadow-blue-200 hover:bg-blue-700 transition w-full">
              ✨ Nueva Solicitud
            </Link>
            <Link href="/mis-solicitudes-cliente" className="flex items-center gap-3 p-4 bg-white border border-gray-100 rounded-2xl font-bold text-gray-700 hover:bg-gray-50 transition w-full">
              📋 Mis Solicitudes
            </Link>
            <Link href="/explorar-tecnico" className="flex items-center gap-3 p-4 bg-white border border-gray-100 rounded-2xl font-bold text-gray-700 hover:bg-gray-50 transition w-full">
              🔍 Explorar Técnicos
            </Link>
            <Link href="/notificaciones" className="flex items-center gap-3 p-4 bg-white border border-gray-100 rounded-2xl font-bold text-gray-700 hover:bg-gray-50 transition w-full">
              🔔 Notificaciones
            </Link>
          </aside>

          {/* CONTENIDO PRINCIPAL DEL CLIENTE */}
          <div className="flex-grow space-y-8">
            <div className="bg-white p-8 rounded-[40px] shadow-sm border border-gray-100">
              <h1 className="text-3xl font-black mb-2">¡Hola de nuevo! 👋</h1>
              <p className="text-gray-500">¿Qué problema vamos a resolver en tu casa hoy?</p>
            </div>

            <section>
              <h3 className="text-xl font-black mb-6">Tus últimas solicitudes</h3>
              {misSolicitudes.length > 0 ? (
                <div className="grid gap-4">
                  {misSolicitudes.map((sol: any) => (
                    <div key={sol.id} className="bg-white p-6 rounded-3xl border border-gray-100 flex justify-between items-center">
                      <div>
                        <p className="font-bold text-lg">{sol.titulo}</p>
                        <span className={`text-[10px] font-black px-2 py-1 rounded-full uppercase ${sol.estado === 'abierta' ? 'bg-green-100 text-green-700' : 'bg-gray-100'}`}>
                          {sol.estado}
                        </span>
                      </div>
                      <Link href={`/solicitud/${sol.id}`} className="text-blue-600 font-bold text-sm">Ver detalles →</Link>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-gray-100/50 rounded-[40px] border-2 border-dashed border-gray-200">
                  <p className="text-gray-400 font-medium">Aún no has publicado ninguna solicitud.</p>
                </div>
              )}
            </section>
          </div>
        </main>

      ) : (
        /* ============================================================
           VISTA: LANDING PARA NO REGISTRADOS (GUEST)
           ============================================================ */
        <>
          <section className="px-8 py-20 max-w-7xl mx-auto text-center md:text-left md:flex items-center">
            <div className="md:w-1/2">
              <span className="bg-blue-50 text-blue-600 px-4 py-2 rounded-full text-xs font-bold uppercase tracking-widest mb-6 inline-block">
                📍 Talagante, Chile
              </span>
              <h1 className="text-6xl md:text-7xl font-black tracking-tighter leading-tight mb-6">
                Tu hogar en buenas <span className="text-blue-600">manos.</span>
              </h1>
              <p className="text-xl text-gray-500 mb-10 max-w-lg leading-relaxed font-medium">
                La plataforma que conecta a los mejores técnicos de Talagante con vecinos que buscan confianza y rapidez.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/login" className="bg-blue-600 text-white text-center px-10 py-4 rounded-2xl font-bold shadow-xl shadow-blue-200 hover:bg-blue-700 transition">
                  Empezar ahora
                </Link>
                <Link href="/registro-test" className="bg-white border-2 border-gray-100 text-center px-10 py-4 rounded-2xl font-bold hover:bg-gray-50 transition">
                  Unirse como Técnico
                </Link>
              </div>
            </div>

            <div className="hidden md:block md:w-1/2 pl-20">
                <div className="bg-gradient-to-br from-blue-50 to-blue-100 w-full h-[500px] rounded-[40px] shadow-2xl flex items-center justify-center relative overflow-hidden">
                   <span className="text-9xl animate-bounce">🏠</span>
                   <div className="absolute bottom-10 left-10 right-10 bg-white/40 backdrop-blur-md p-6 rounded-2xl border border-white/20">
                      <p className="text-sm font-bold text-blue-800">Inicia sesión para acceder a tu panel de control y gestionar tus solicitudes.</p>
                   </div>
                </div>
            </div>
          </section>

          <section className="bg-blue-600 py-20 px-8">
            <div className="max-w-7xl mx-auto text-center text-white">
              <h2 className="text-4xl font-black mb-4">¿Necesitas ayuda técnica?</h2>
              <p className="text-blue-100 mb-12 text-lg font-medium">Regístrate en 1 minuto y publica tu problema para recibir presupuestos.</p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
                {['Electricidad', 'Gasfitería', 'Hogar', 'Pintura'].map(s => (
                  <div key={s} className="bg-white/10 backdrop-blur-sm p-6 rounded-3xl border border-white/10">
                    <p className="font-black text-xl">{s}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </>
      )}

      {/* --- FOOTER COMÚN --- */}
      <footer className="py-12 px-8 border-t border-gray-100 text-center text-gray-400 text-sm font-medium bg-white">
        <p>© 2026 ConfiaCL - Talagante. Conectando comunidad.</p>
      </footer>
    </div>
  )
}