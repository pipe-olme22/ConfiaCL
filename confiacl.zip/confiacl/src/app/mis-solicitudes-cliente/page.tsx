'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { apiCall } from '@/lib/api-client'
import type { Solicitud, Propuesta } from '@/types'

interface SolicitudConPropuestas extends Solicitud {
  propuestas: (Propuesta & { usuario_nombre?: string })[]
}

export default function MisSolicitudes() {
  const router = useRouter()
  const [solicitudes, setSolicitudes] = useState<SolicitudConPropuestas[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [acceptingId, setAcceptingId] = useState<string | null>(null)

  useEffect(() => {
    cargarSolicitudes()
  }, [])

  async function cargarSolicitudes() {
    try {
      setLoading(true)
      setError(null)
      
      const response = await apiCall<SolicitudConPropuestas[]>('/api/requests/my-requests')
      if (!response.success) {
        if (response.error === 'Unauthorized') {
          router.push('/login')
          return
        }
        throw new Error(response.error || 'No se pudieron cargar tus solicitudes')
      }

      setSolicitudes(response.data || [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }

  async function aceptarPropuesta(propuestaId: string, solicitudId: string) {
    const confirmar = confirm('¿Aceptar esta propuesta? Se cerrará la búsqueda.')
    if (!confirmar) return

    try {
      setAcceptingId(propuestaId)
      const response = await apiCall('/api/proposals/[id]/accept', {
        method: 'POST',
        body: JSON.stringify({ solicitud_id: solicitudId })
      })

      if (!response.success) {
        throw new Error(response.error || 'No se pudo aceptar la propuesta')
      }

      // Recargar solicitudes
      await cargarSolicitudes()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al aceptar propuesta')
    } finally {
      setAcceptingId(null)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-6xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-4xl font-black text-gray-900">Mis Solicitudes</h1>
          <p className="text-gray-600 mt-2">Gestiona todas tus solicitudes de servicio</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            {error}
          </div>
        )}

        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin">⏳</div>
            <p className="text-gray-600 mt-2">Cargando solicitudes...</p>
          </div>
        ) : solicitudes.length === 0 ? (
          <Card>
            <div className="text-center py-12">
              <p className="text-gray-600 mb-4">Aún no has publicado ninguna solicitud.</p>
              <Button onClick={() => router.push('/nueva-solicitud-cliente')}>
                Crear Solicitud
              </Button>
            </div>
          </Card>
        ) : (
          <div className="space-y-6">
            {solicitudes.map((sol) => (
              <Card key={sol.id}>
                <div className="flex justify-between items-start mb-6 pb-4 border-b border-gray-200">
                  <div className="flex-1">
                    <h2 className="text-2xl font-bold text-gray-900">{sol.titulo}</h2>
                    <p className="text-gray-600 text-sm mt-1">{sol.descripcion}</p>
                  </div>
                  <Badge variant={sol.estado === 'abierta' ? 'success' : 'info'}>
                    {sol.estado === 'abierta' ? 'Abierta' : 'En Proceso'}
                  </Badge>
                </div>

                <div className="mb-6">
                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-gray-600">Presupuesto</p>
                      <p className="text-lg font-bold text-green-600">
                        ${sol.presupuesto_estimado?.toLocaleString('es-CL') || 'N/A'}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Comuna</p>
                      <p className="text-lg font-bold text-gray-900">{sol.comuna || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Categoría</p>
                      <p className="text-lg font-bold text-gray-900">{sol.categoria_id || 'N/A'}</p>
                    </div>
                  </div>
                </div>

                {/* Propuestas */}
                <div className="mt-8">
                  <h3 className="font-bold text-gray-900 mb-4">
                    Propuestas Recibidas ({sol.propuestas?.length || 0})
                  </h3>

                  {sol.propuestas && sol.propuestas.length > 0 ? (
                    <div className="space-y-3">
                      {sol.propuestas.map((prop) => (
                        <div
                          key={prop.id}
                          className={`p-4 rounded-lg border-2 transition ${
                            prop.estado === 'aceptada'
                              ? 'bg-blue-50 border-blue-500 ring-2 ring-blue-300'
                              : 'bg-gray-50 border-gray-200 hover:border-blue-300'
                          }`}
                        >
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <p className="font-bold text-gray-900">{prop.tecnico?.nombre_completo || 'Técnico'}</p>
                              <p className="text-sm text-gray-600 mt-1">{prop.mensaje}</p>
                              <p className="text-xs text-gray-500 mt-2">
                                {new Date(prop.fecha_creacion || '').toLocaleDateString('es-CL')}
                              </p>
                            </div>
                            <div className="text-right ml-4">
                              <p className="text-2xl font-black text-green-600">
                                ${prop.precio_ofertado?.toLocaleString('es-CL') || 'N/A'}
                              </p>
                              {sol.estado === 'abierta' && prop.estado === 'pendiente' && (
                                <Button
                                  onClick={() => aceptarPropuesta(prop.id, sol.id)}
                                  disabled={acceptingId === prop.id}
                                  className="mt-3"
                                  size="sm"
                                >
                                  {acceptingId === prop.id ? 'Procesando...' : 'Aceptar'}
                                </Button>
                              )}
                              {prop.estado === 'aceptada' && (
                                <Badge variant="success" className="mt-3">
                                  Aceptada
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 text-center py-6">Sin propuestas aún</p>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
