'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { API } from '@/lib/api-client'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    // Llamar al nuevo API endpoint seguro
    const result = await API.login(email, password)

    if (!result.success) {
      setError(result.error || 'Error al iniciar sesión')
      setLoading(false)
      return
    }

    // Guardar token en localStorage
    const userData = result.data as any
    if (userData.token) {
      localStorage.setItem('auth_token', userData.token)
    }

    // Si fue exitoso, redirigir según rol
    if (userData.isAdmin) {
      router.push('/admin')
    } else if (userData.role === 'tecnico') {
      router.push('/dashboard-tecnico')
    } else {
      router.push('/nueva-solicitud-cliente')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-6">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl p-10 border border-gray-100">
        <h1 className="text-3xl font-black text-gray-900 mb-2">Entrar a ConfiaCL</h1>
        <p className="text-gray-500 mb-8 font-medium">Accede a tu cuenta según tu perfil.</p>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm font-medium">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Correo Electrónico</label>
            <input 
              type="email" 
              placeholder="ejemplo@gmail.com"
              className="w-full p-4 rounded-2xl bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white outline-none transition text-gray-900"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Contraseña</label>
            <input 
              type="password" 
              placeholder="••••••••"
              className="w-full p-4 rounded-2xl bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white outline-none transition text-gray-900"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              disabled={loading}
            />
          </div>

          <button 
            type="submit" 
            disabled={loading}
            className="w-full bg-blue-600 text-white font-black py-4 rounded-2xl hover:bg-blue-700 transition shadow-lg shadow-blue-200 disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            {loading ? 'Validando...' : 'Iniciar Sesión'}
          </button>
        </form>

        <p className="text-gray-500 text-sm text-center mt-6">
          ¿No tienes cuenta?{' '}
          <button 
            onClick={() => router.push('/registro-test')}
            className="text-blue-600 font-bold hover:underline"
          >
            Regístrate aquí
          </button>
        </p>
      </div>
    </div>
  )
}