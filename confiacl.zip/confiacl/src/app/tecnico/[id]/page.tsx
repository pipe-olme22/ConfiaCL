'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useParams } from 'next/navigation'

export default function PerfilPublico() {
  const { id } = useParams()
  const [tecnico, setTecnico] = useState<any>(null)
  const [resenas, setResenas] = useState<any[]>([]) // Nuevo: Estado para la lista de comentarios
  const [promedio, setPromedio] = useState<string>("0.0")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function cargarDatos() {
      // 1. Datos del técnico
      const { data: userRecord } = await supabase
        .from('usuarios')
        .select(`nombre_completo, rol, perfiles_tecnicos (*)`)
        .eq('id', id).eq('rol', 'tecnico').maybeSingle()

      if (userRecord) {
        setTecnico(userRecord)
        
        // 2. Traer Reseñas + Nombre del Cliente que la escribió (Join con usuarios)
        const { data: listaResenas } = await supabase
          .from('resenas')
          .select(`
            puntuacion,
            comentario,
            fecha_creacion,
            usuarios:cliente_id ( nombre_completo )
          `)
          .eq('tecnico_id', id)
          .order('fecha_creacion', { ascending: false })

        if (listaResenas) {
          setResenas(listaResenas)
          // Cálculo de promedio
          const suma = listaResenas.reduce((acc, curr) => acc + curr.puntuacion, 0)
          setPromedio(listaResenas.length > 0 ? (suma / listaResenas.length).toFixed(1) : "Nuevo")
        }
      }
      setLoading(false)
    }
    if (id) cargarDatos()
  }, [id])

  if (loading) return <div className="p-10 text-center animate-pulse">Cargando perfil...</div>
  if (!tecnico) return <div className="p-10 text-center">Técnico no encontrado</div>

  const perfil = tecnico.perfiles_tecnicos

  return (
    <div className="max-w-4xl mx-auto p-6 font-sans space-y-8">
      {/* TARJETA PRINCIPAL (La que ya tienes) */}
      <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
        <div className="bg-blue-600 h-32"></div>
        <div className="px-8 pb-8">
          <div className="relative -mt-16 flex items-end gap-6 mb-6">
            <img src={perfil.foto_perfil_url || '/placeholder.png'} className="w-40 h-40 rounded-2xl object-cover border-4 border-white shadow-lg bg-gray-200" />
            <div className="pb-2">
              <h1 className="text-3xl font-bold text-gray-900">{tecnico.nombre_completo}</h1>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-yellow-400">★</span>
                <span className="font-bold">{promedio}</span>
                <span className="text-gray-400 text-sm">({resenas.length} opiniones)</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-xl text-center">
                <p className="text-xs text-gray-400 uppercase font-bold">Valor Visita</p>
                <p className="font-black text-xl text-green-600">${perfil.valor_visita?.toLocaleString('es-CL')}</p>
              </div>
              {perfil.certificado_sec && (
                <div className="bg-yellow-50 border border-yellow-200 p-3 rounded-xl text-center">
                  <p className="text-[10px] font-black text-yellow-800 uppercase">⚡ Instalador SEC</p>
                </div>
              )}
            </div>
            <div className="md:col-span-2">
              <h2 className="font-bold text-gray-800 mb-2">Biografía</h2>
              <p className="text-gray-600 text-sm leading-relaxed">{perfil.biografia}</p>
              <button className="w-full mt-6 bg-blue-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-100">Contactar Ahora</button>
            </div>
          </div>
        </div>
      </div>

      {/* SECCIÓN DE RESEÑAS (Nueva) */}
      <div className="space-y-4">
        <h2 className="text-2xl font-black text-gray-900">Opiniones de clientes</h2>
        {resenas.length === 0 ? (
          <p className="text-gray-400 italic">Este técnico aún no tiene reseñas. ¡Sé el primero en calificarlo!</p>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {resenas.map((r, i) => (
              <div key={i} className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-bold text-gray-800">{r.usuarios?.nombre_completo || 'Cliente ConfiaCL'}</p>
                    <div className="text-yellow-400 text-xs">
                      {'★'.repeat(r.puntuacion)}{'☆'.repeat(5 - r.puntuacion)}
                    </div>
                  </div>
                  <span className="text-gray-300 text-xs">{new Date(r.fecha_creacion).toLocaleDateString('es-CL')}</span>
                </div>
                <p className="text-gray-600 text-sm italic">"{r.comentario}"</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}