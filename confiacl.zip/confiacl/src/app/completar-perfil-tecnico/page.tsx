'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Badge } from '@/components/ui/Badge'
import { apiCall } from '@/lib/api-client'
import type { User } from '@/types'

interface TecnicoPerfil extends User {
  perfiles_tecnicos?: {
    id: string
    biografia: string
    anos_experiencia: number
    foto_perfil_url?: string
    valor_visita: number
    especialidades: string[]
    categoria_id: string
  }
}

const ESPECIALIDADES_DISPONIBLES = [
  'Plomería',
  'Electricidad',
  'Carpintería',
  'Climatización',
  'Pintura',
  'Jardinería',
  'Reparación de Electrodomésticos',
  'Servicio Técnico de Computadoras',
]

export default function CompletarPerfilTecnico() {
  const router = useRouter()
  const [usuario, setUsuario] = useState<TecnicoPerfil | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    biografia: '',
    anos_experiencia: 0,
    valor_visita: 0,
    especialidades: [] as string[],
  })

  useEffect(() => {
    cargarPerfil()
  }, [])

  async function cargarPerfil() {
    try {
      setLoading(true)
      const response = await apiCall<User>('/api/auth/me')
      if (!response.success) {
        if (response.error === 'Unauthorized') {
          router.push('/login')
          return
        }
        throw new Error(response.error || 'No se pudo cargar tu perfil')
      }

      const usuario = response.data as any
      setUsuario(usuario)

      if (usuario?.perfiles_tecnicos?.[0]) {
        const perfil = usuario.perfiles_tecnicos[0]
        setFormData({
          biografia: perfil.biografia || '',
          anos_experiencia: perfil.anos_experiencia || 0,
          valor_visita: perfil.valor_visita || 0,
          especialidades: perfil.especialidades || [],
        })
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }

  async function guardarPerfil() {
    if (!formData.biografia.trim()) {
      alert('Por favor ingresa una biografía')
      return
    }

    if (formData.especialidades.length === 0) {
      alert('Por favor selecciona al menos una especialidad')
      return
    }

    try {
      setSaving(true)
      setError(null)

      // Este endpoint necesitaría ser implementado
      const response = await apiCall('/api/auth/complete-technical-profile', {
        method: 'POST',
        body: JSON.stringify(formData),
      })

      if (!response.success) {
        throw new Error(response.error || 'No se pudo guardar tu perfil técnico')
      }

      alert('¡Perfil técnico completado exitosamente!')
      router.push('/dashboard-tecnico')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setSaving(false)
    }
  }

  function toggleEspecialidad(esp: string) {
    setFormData((prev) => ({
      ...prev,
      especialidades: prev.especialidades.includes(esp)
        ? prev.especialidades.filter((e) => e !== esp)
        : [...prev.especialidades, esp],
    }))
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-2xl mx-auto p-6 text-center py-12">
          <div className="inline-block animate-spin">⏳</div>
          <p className="text-gray-600 mt-2">Cargando perfil...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-2xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-4xl font-black text-gray-900">
            Completa tu Perfil Técnico
          </h1>
          <p className="text-gray-600 mt-2">
            Cuéntales a los clientes quién eres y qué sabes hacer
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            {error}
          </div>
        )}

        <Card>
          <div className="space-y-6">
            {/* Biografía */}
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">
                Sobre Ti
              </label>
              <textarea
                placeholder="Cuéntanos sobre tu experiencia, certificaciones, y qué te hace diferente..."
                value={formData.biografia}
                onChange={(e) =>
                  setFormData({ ...formData, biografia: e.target.value })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={6}
              />
              <p className="text-xs text-gray-500 mt-1">
                Mínimo 50 caracteres
              </p>
            </div>

            {/* Años de Experiencia */}
            <div>
              <Input
                type="number"
                label="Años de Experiencia"
                min="0"
                value={formData.anos_experiencia}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    anos_experiencia: parseInt(e.target.value) || 0,
                  })
                }
              />
            </div>

            {/* Valor de Visita */}
            <div>
              <Input
                type="number"
                label="Valor de Visita Técnica ($CLP)"
                min="0"
                value={formData.valor_visita}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    valor_visita: parseInt(e.target.value) || 0,
                  })
                }
              />
              <p className="text-xs text-gray-500 mt-1">
                Precio que cobras por una visita inicial
              </p>
            </div>

            {/* Especialidades */}
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-3">
                Especialidades (selecciona al menos una)
              </label>
              <div className="flex flex-wrap gap-2">
                {ESPECIALIDADES_DISPONIBLES.map((esp) => (
                  <button
                    key={esp}
                    onClick={() => toggleEspecialidad(esp)}
                    className={`px-4 py-2 rounded-full font-medium transition ${
                      formData.especialidades.includes(esp)
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    }`}
                  >
                    {esp}
                  </button>
                ))}
              </div>
              <p className="text-xs text-gray-500 mt-2">
                Seleccionadas: {formData.especialidades.length}
              </p>
            </div>

            {/* Acciones */}
            <div className="flex gap-2 justify-end pt-6 border-t border-gray-200">
              <Button variant="secondary" onClick={() => router.back()}>
                Cancelar
              </Button>
              <Button onClick={guardarPerfil} disabled={saving}>
                {saving ? 'Guardando...' : 'Completar Perfil'}
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
