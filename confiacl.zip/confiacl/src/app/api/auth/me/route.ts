// src/app/api/auth/me/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { supabaseClient } from '@/lib/supabase-server'

export async function GET(request: NextRequest) {
  try {
    // Obtener token de Authorization header o cookie
    const authHeader = request.headers.get('Authorization')
    const token = authHeader?.replace('Bearer ', '') || request.cookies.get('auth_token')?.value

    if (!token) {
      return NextResponse.json(
        {
          success: false,
          error: 'No autenticado',
        },
        { status: 401 }
      )
    }

    // Obtener sesión usando token
    const { data: { user }, error } = await supabaseClient.auth.getUser(token)

    if (error || !user) {
      return NextResponse.json(
        {
          success: false,
          error: 'Token inválido o expirado',
        },
        { status: 401 }
      )
    }

    // Obtener perfil completo
    const { data: usuarioData, error: usuarioError } = await supabaseClient
      .from('usuarios')
      .select('id, email, nombre_completo, rut, rol, es_admin, telefono, fecha_registro')
      .eq('id', user.id)
      .single()

    if (usuarioError || !usuarioData) {
      return NextResponse.json(
        {
          success: false,
          error: 'No se encontró el usuario',
        },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      data: usuarioData,
    })
  } catch (error) {
    console.error('Auth me error:', error)
    return NextResponse.json(
      {
        success: false,
        error: 'Error interno del servidor',
      },
      { status: 500 }
    )
  }
}
