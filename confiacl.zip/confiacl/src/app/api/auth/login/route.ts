// src/app/api/auth/login/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { supabaseClient } from '@/lib/supabase-server'
import { validarEmail, validarPassword } from '@/lib/validaciones'

interface LoginRequest {
  email: string
  password: string
}

async function validateLoginRequest(body: any): Promise<{ valid: boolean; errors?: Record<string, string> }> {
  const errors: Record<string, string> = {}

  if (!body.email || !body.email.trim()) {
    errors.email = 'El email es requerido'
  } else if (!validarEmail(body.email)) {
    errors.email = 'Email inválido'
  }

  if (!body.password || !body.password.trim()) {
    errors.password = 'La contraseña es requerida'
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors: Object.keys(errors).length > 0 ? errors : undefined,
  }
}

export async function POST(request: NextRequest) {
  try {
    const body: LoginRequest = await request.json()

    // Validar entrada
    const validation = await validateLoginRequest(body)
    if (!validation.valid) {
      return NextResponse.json(
        {
          success: false,
          error: 'Validación fallida',
          errors: validation.errors,
        },
        { status: 400 }
      )
    }

    // Autenticar con Supabase Auth
    const { data: authData, error: authError } = await supabaseClient.auth.signInWithPassword({
      email: body.email,
      password: body.password,
    })

    if (authError || !authData.user) {
      return NextResponse.json(
        {
          success: false,
          error: 'Email o contraseña incorrectos. Por favor intenta de nuevo.',
        },
        { status: 401 }
      )
    }

    // Obtener perfil del usuario
    const { data: usuarioData, error: usuarioError } = await supabaseClient
      .from('usuarios')
      .select('id, nombre_completo, rut, rol, es_admin, telefono, fecha_registro, email')
      .eq('id', authData.user.id)
      .single()

    if (usuarioError || !usuarioData) {
      return NextResponse.json(
        {
          success: false,
          error: 'No se encontró el perfil del usuario',
        },
        { status: 404 }
      )
    }

    // Crear respuesta con JWT
    const response = NextResponse.json(
      {
        success: true,
        data: {
          user: usuarioData,
          token: authData.session?.access_token,
          role: usuarioData.rol,
          isAdmin: usuarioData.es_admin,
        },
      },
      { status: 200 }
    )

    // Guardar token en cookie segura (httpOnly)
    if (authData.session?.access_token) {
      response.cookies.set('auth_token', authData.session.access_token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 60 * 60 * 24 * 7, // 7 días
      })
    }

    return response
  } catch (error) {
    console.error('Login error:', error)
    return NextResponse.json(
      {
        success: false,
        error: 'Error interno del servidor',
      },
      { status: 500 }
    )
  }
}
