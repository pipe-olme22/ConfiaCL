// src/app/api/auth/complete-technical-profile/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { supabaseClient } from '@/lib/supabase-server'

export async function POST(request: NextRequest) {
  try {
    // Obtener token de Authorization header o cookie
    const authHeader = request.headers.get('Authorization')
    const token = authHeader?.replace('Bearer ', '') || request.cookies.get('auth_token')?.value

    if (!token) {
      return NextResponse.json(
        { success: false, error: 'No autenticado' },
        { status: 401 }
      )
    }

    // Obtener usuario actual
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser(token)

    if (userError || !user) {
      return NextResponse.json(
        { success: false, error: 'Token inválido' },
        { status: 401 }
      )
    }

    // Parsear body
    const body = await request.json()
    const { biografia, anos_experiencia, valor_visita, especialidades } = body

    // Validar campos requeridos
    if (!biografia || !anos_experiencia === undefined || !valor_visita === undefined) {
      return NextResponse.json(
        { success: false, error: 'Faltan campos requeridos' },
        { status: 400 }
      )
    }

    // Upsert en perfiles_tecnicos
    const { data, error } = await supabaseClient
      .from('perfiles_tecnicos')
      .upsert(
        {
          usuario_id: user.id,
          biografia,
          anos_experiencia,
          valor_visita,
          especialidades: especialidades || [],
        },
        { onConflict: 'usuario_id' }
      )
      .select()
      .single()

    if (error) {
      console.error('Complete profile error:', error)
      return NextResponse.json(
        { success: false, error: error.message },
        { status: 400 }
      )
    }

    return NextResponse.json({
      success: true,
      data,
    })
  } catch (error) {
    console.error('Complete technical profile error:', error)
    return NextResponse.json(
      { success: false, error: 'Error al completar perfil técnico' },
      { status: 500 }
    )
  }
}
