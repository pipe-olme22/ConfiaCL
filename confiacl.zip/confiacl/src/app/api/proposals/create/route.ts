// src/app/api/proposals/create/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { supabaseClient } from '@/lib/supabase-server'
import { sanitizeString } from '@/lib/validaciones'

interface CreateProposalBody {
  solicitud_id: string
  precio_ofertado: number
  mensaje: string
}

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization')
    const token = authHeader?.replace('Bearer ', '') || request.cookies.get('auth_token')?.value

    if (!token) {
      return NextResponse.json(
        { success: false, error: 'No autenticado' },
        { status: 401 }
      )
    }

    // Obtener usuario actual
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser(token)

    if (userError || !user) {
      return NextResponse.json(
        { success: false, error: 'Token inválido' },
        { status: 401 }
      )
    }

    const body: CreateProposalBody = await request.json()
    const errors: Record<string, string> = {}

    // Validación exhaustiva
    if (!body.solicitud_id) {
      errors.solicitud_id = 'La solicitud es requerida'
    }

    if (!body.precio_ofertado || body.precio_ofertado <= 0) {
      errors.precio_ofertado = 'El precio debe ser mayor a 0'
    }

    if (!body.mensaje || body.mensaje.trim().length < 5) {
      errors.mensaje = 'El mensaje debe tener al menos 5 caracteres'
    }

    if (Object.keys(errors).length > 0) {
      return NextResponse.json(
        {
          success: false,
          error: 'Validación fallida',
          errors,
        },
        { status: 400 }
      )
    }

    // Verificar que la solicitud existe
    const { data: solicitud, error: solicitudError } = await supabaseClient
      .from('solicitudes')
      .select('id, cliente_id')
      .eq('id', body.solicitud_id)
      .single()

    if (solicitudError || !solicitud) {
      return NextResponse.json(
        { success: false, error: 'Solicitud no encontrada' },
        { status: 404 }
      )
    }

    // Verificar que no sea el cliente quien hace la propuesta
    if (solicitud.cliente_id === user.id) {
      return NextResponse.json(
        { success: false, error: 'No puedes hacer propuesta en tu propia solicitud' },
        { status: 403 }
      )
    }

    // Crear propuesta
    const propuesta = {
      solicitud_id: body.solicitud_id,
      tecnico_id: user.id,
      precio_ofertado: body.precio_ofertado,
      mensaje: sanitizeString(body.mensaje),
      estado: 'pendiente',
      // fecha_creacion será generada automáticamente por Supabase
    }

    const { data, error } = await supabaseClient
      .from('propuestas')
      .insert([propuesta])
      .select()
      .single()

    if (error) {
      console.error('DB error:', error)
      return NextResponse.json(
        { success: false, error: 'Error al crear propuesta' },
        { status: 500 }
      )
    }

    return NextResponse.json(
      {
        success: true,
        data,
        message: 'Propuesta creada correctamente',
      },
      { status: 201 }
    )
  } catch (error) {
    console.error('Create proposal error:', error)
    return NextResponse.json(
      { success: false, error: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
