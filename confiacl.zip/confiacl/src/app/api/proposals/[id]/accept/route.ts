// src/app/api/proposals/[id]/accept/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { supabaseClient } from '@/lib/supabase-server'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const authHeader = request.headers.get('Authorization')
    const token = authHeader?.replace('Bearer ', '') || request.cookies.get('auth_token')?.value

    if (!token) {
      return NextResponse.json(
        { success: false, error: 'No autenticado' },
        { status: 401 }
      )
    }

    // Obtener usuario actual
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser(token)

    if (userError || !user) {
      return NextResponse.json(
        { success: false, error: 'Token inválido' },
        { status: 401 }
      )
    }

    // Obtener propuesta
    const { data: propuesta, error: propuestaError } = await supabaseClient
      .from('propuestas')
      .select('solicitud_id')
      .eq('id', id)
      .single()

    if (propuestaError || !propuesta) {
      return NextResponse.json(
        { success: false, error: 'Propuesta no encontrada' },
        { status: 404 }
      )
    }

    // Verificar que el usuario es el cliente de la solicitud
    const { data: solicitud, error: solicitudError } = await supabaseClient
      .from('solicitudes')
      .select('cliente_id')
      .eq('id', propuesta.solicitud_id)
      .single()

    if (solicitudError || !solicitud || solicitud.cliente_id !== user.id) {
      return NextResponse.json(
        { success: false, error: 'No tienes permiso para aceptar esta propuesta' },
        { status: 403 }
      )
    }

    // Aceptar propuesta
    const { data, error } = await supabaseClient
      .from('propuestas')
      .update({ estado: 'aceptada' })
      .eq('id', id)
      .select()
      .single()

    if (error) {
      return NextResponse.json(
        { success: false, error: 'Error al aceptar propuesta' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      success: true,
      data,
      message: 'Propuesta aceptada correctamente',
    })
  } catch (error) {
    console.error('Accept proposal error:', error)
    return NextResponse.json(
      { success: false, error: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
