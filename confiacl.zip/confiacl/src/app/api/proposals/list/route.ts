// src/app/api/proposals/list/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { supabaseClient } from '@/lib/supabase-server'

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('auth_token')?.value

    if (!token) {
      return NextResponse.json(
        { success: false, error: 'No autenticado' },
        { status: 401 }
      )
    }

    const { searchParams } = new URL(request.url)
    const solicitudId = searchParams.get('solicitud_id')

    if (!solicitudId) {
      return NextResponse.json(
        { success: false, error: 'solicitud_id es requerido' },
        { status: 400 }
      )
    }

    const { data, error } = await supabaseClient
      .from('propuestas')
      .select(
        `
        *,
        tecnico:tecnico_id(id, nombre_completo, email, telefono)
      `
      )
      .eq('solicitud_id', solicitudId)
      .order('fecha_creacion', { ascending: false })

    if (error) {
      return NextResponse.json(
        { success: false, error: error.message },
        { status: 400 }
      )
    }

    return NextResponse.json({
      success: true,
      data: data || [],
    })
  } catch (error) {
    console.error('Get proposals error:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener propuestas' },
      { status: 500 }
    )
  }
}
