// src/app/api/requests/create/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { supabaseClient } from '@/lib/supabase-server'
import { sanitizeString, validarPresupuesto } from '@/lib/validaciones'

interface CreateRequestBody {
  titulo: string
  descripcion: string
  categoria_id: number
  presupuesto_estimado?: number
  comuna: string
}

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization')
    const token = authHeader?.replace('Bearer ', '') || request.cookies.get('auth_token')?.value

    if (!token) {
      return NextResponse.json(
        { success: false, error: 'No autenticado' },
        { status: 401 }
      )
    }

    // Obtener usuario actual
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser(token)

    if (userError || !user) {
      return NextResponse.json(
        { success: false, error: 'Token inválido' },
        { status: 401 }
      )
    }

    const body: CreateRequestBody = await request.json()
    const errors: Record<string, string> = {}

    // Validación exhaustiva
    if (!body.titulo || body.titulo.trim().length < 5) {
      errors.titulo = 'El título debe tener al menos 5 caracteres'
    }

    if (!body.descripcion || body.descripcion.trim().length < 10) {
      errors.descripcion = 'La descripción debe tener al menos 10 caracteres'
    }

    if (!body.categoria_id || body.categoria_id <= 0) {
      errors.categoria_id = 'La categoría es requerida'
    }

    if (!body.comuna || body.comuna.trim().length < 3) {
      errors.comuna = 'La comuna es requerida'
    }

    if (body.presupuesto_estimado && body.presupuesto_estimado < 0) {
      errors.presupuesto_estimado = 'El presupuesto no puede ser negativo'
    }

    if (Object.keys(errors).length > 0) {
      return NextResponse.json(
        {
          success: false,
          error: 'Validación fallida',
          errors,
        },
        { status: 400 }
      )
    }

    // Sanitizar strings y preparar datos
    const solicitud = {
      cliente_id: user.id,
      titulo: sanitizeString(body.titulo),
      descripcion: sanitizeString(body.descripcion),
      categoria_id: body.categoria_id,
      presupuesto_estimado: body.presupuesto_estimado || null,
      comuna: sanitizeString(body.comuna),
      estado: 'abierta',
      // fecha_creacion será generada automáticamente por Supabase
    }

    // Insertar en DB
    const { data, error } = await supabaseClient
      .from('solicitudes')
      .insert([solicitud])
      .select()
      .single()

    if (error) {
      console.error('DB error:', error)
      return NextResponse.json(
        { success: false, error: 'Error al crear solicitud' },
        { status: 500 }
      )
    }

    return NextResponse.json(
      {
        success: true,
        data,
        message: 'Solicitud creada correctamente',
      },
      { status: 201 }
    )
  } catch (error) {
    console.error('Create request error:', error)
    return NextResponse.json(
      { success: false, error: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
