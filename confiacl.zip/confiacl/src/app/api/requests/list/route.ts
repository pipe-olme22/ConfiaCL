// src/app/api/requests/list/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { supabaseClient } from '@/lib/supabase-server'

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('auth_token')?.value

    if (!token) {
      return NextResponse.json(
        { success: false, error: 'No autenticado' },
        { status: 401 }
      )
    }

    const { searchParams } = new URL(request.url)
    const estado = searchParams.get('estado')
    const categoria = searchParams.get('categoria')
    const limit = parseInt(searchParams.get('limit') || '10')
    const offset = parseInt(searchParams.get('offset') || '0')

    let query = supabaseClient
      .from('solicitudes')
      .select(
        `
        *,
        cliente:cliente_id(id, nombre_completo, email, telefono)
      `,
        { count: 'exact' }
      )
      .order('fecha_creacion', { ascending: false })

    if (estado) {
      query = query.eq('estado', estado)
    }

    if (categoria) {
      query = query.eq('categoria_id', categoria)
    }

    const { data, count, error } = await query.range(offset, offset + limit - 1)

    if (error) {
      return NextResponse.json(
        { success: false, error: error.message },
        { status: 400 }
      )
    }

    return NextResponse.json({
      success: true,
      data: {
        solicitudes: data || [],
        total: count || 0,
      },
    })
  } catch (error) {
    console.error('Get requests error:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener solicitudes' },
      { status: 500 }
    )
  }
}
