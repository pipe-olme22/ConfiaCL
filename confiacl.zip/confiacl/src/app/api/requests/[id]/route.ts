// src/app/api/requests/[id]/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { supabaseClient } from '@/lib/supabase-server'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const token = request.cookies.get('auth_token')?.value

    if (!token) {
      return NextResponse.json(
        { success: false, error: 'No autenticado' },
        { status: 401 }
      )
    }

    const { data, error } = await supabaseClient
      .from('solicitudes')
      .select(
        `
        *,
        cliente:cliente_id(id, nombre_completo, email, telefono)
      `
      )
      .eq('id', id)
      .single()

    if (error || !data) {
      return NextResponse.json(
        { success: false, error: 'Solicitud no encontrada' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      data,
    })
  } catch (error) {
    console.error('Get request error:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener solicitud' },
      { status: 500 }
    )
  }
}
