'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { apiCall } from '@/lib/api-client'
import type { User } from '@/types'

export default function EditorPerfil() {
  const router = useRouter()
  const [usuario, setUsuario] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    nombre_completo: '',
    email: '',
    telefono: '',
  })

  useEffect(() => {
    cargarPerfil()
  }, [])

  async function cargarPerfil() {
    try {
      setLoading(true)
      const response = await apiCall<User>('/api/auth/me')
      if (!response.success) {
        if (response.error === 'Unauthorized') {
          router.push('/login')
          return
        }
        throw new Error(response.error || 'No se pudo cargar tu perfil')
      }

      const usuario = response.data
      if (usuario) {
        setUsuario(usuario)
        setFormData({
          nombre_completo: usuario.nombre_completo || '',
          email: usuario.email || '',
          telefono: usuario.telefono || '',
        })
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }

  async function guardarCambios() {
    try {
      setSaving(true)
      setError(null)

      // Este endpoint necesitaría ser creado en tu backend
      // Por ahora usamos un placeholder
      const response = await apiCall('/api/auth/update-profile', {
        method: 'PATCH',
        body: JSON.stringify(formData),
      })

      if (!response.success) {
        throw new Error(response.error || 'No se pudieron guardar los cambios')
      }

      alert('Perfil actualizado con éxito')
      await cargarPerfil()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-2xl mx-auto p-6 text-center py-12">
          <div className="inline-block animate-spin">⏳</div>
          <p className="text-gray-600 mt-2">Cargando perfil...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-2xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-4xl font-black text-gray-900">Mi Perfil</h1>
          <p className="text-gray-600 mt-2">Edita tu información personal</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            {error}
          </div>
        )}

        <Card>
          <div className="space-y-6">
            <div>
              <Input
                label="Nombre Completo"
                value={formData.nombre_completo}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    nombre_completo: e.target.value,
                  })
                }
              />
            </div>

            <div>
              <Input
                label="Email"
                type="email"
                value={formData.email}
                onChange={(e) =>
                  setFormData({ ...formData, email: e.target.value })
                }
                disabled
              />
              <p className="text-xs text-gray-500 mt-1">
                El email no puede ser modificado
              </p>
            </div>

            <div>
              <Input
                label="Teléfono"
                type="tel"
                value={formData.telefono}
                onChange={(e) =>
                  setFormData({ ...formData, telefono: e.target.value })
                }
              />
            </div>

            <div className="flex gap-2 justify-end pt-6 border-t border-gray-200">
              <Button variant="secondary" onClick={() => cargarPerfil()}>
                Cancelar
              </Button>
              <Button onClick={guardarCambios} disabled={saving}>
                {saving ? 'Guardando...' : 'Guardar Cambios'}
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
