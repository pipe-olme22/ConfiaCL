'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { ProposalCard } from '@/components/ProposalCard'
import { apiCall } from '@/lib/api-client'
import type { User, Propuesta, Solicitud } from '@/types'

interface ProyectoActivo extends Propuesta {
  solicitud?: Solicitud
}

export default function DashboardTecnico() {
  const router = useRouter()
  const [usuario, setUsuario] = useState<User | null>(null)
  const [proyectos, setProyectos] = useState<ProyectoActivo[]>([])
  const [stats, setStats] = useState({
    ganados: 0,
    total: 0,
    promedio: 0,
    enProceso: 0,
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    cargarDashboard()
  }, [])

  async function cargarDashboard() {
    try {
      setLoading(true)
      setError(null)

      // Obtener usuario actual
      const meResponse = await apiCall<User>('/api/auth/me')
      if (!meResponse.success) {
        if (meResponse.error === 'Unauthorized') {
          router.push('/login')
          return
        }
        throw new Error(meResponse.error || 'No se pudo obtener tu perfil')
      }

      const meData = meResponse.data
      if (meData) {
        setUsuario(meData)
      }

      // Obtener propuestas del técnico
      const proposalsResponse = await apiCall<Propuesta[]>('/api/proposals/list')
      if (proposalsResponse.success) {
        const propuestas = proposalsResponse.data || []

        // Calcular estadísticas
        const ganados = propuestas.filter(
          (p: Propuesta) => p.estado === 'aceptada'
        ).length
        const enProceso = propuestas.filter(
          (p: Propuesta) => p.estado === 'aceptada'
        ).length

        setStats({
          ganados,
          total: propuestas.length,
          promedio: 4.8, // Esto vendría de un endpoint de reseñas
          enProceso,
        })

        setProyectos(propuestas.slice(0, 5))
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-6xl mx-auto p-6 text-center py-12">
          <div className="inline-block animate-spin">⏳</div>
          <p className="text-gray-600 mt-2">Cargando tu dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-6xl mx-auto p-6">
        {/* Bienvenida */}
        <div className="mb-12">
          <h1 className="text-4xl font-black text-gray-900 mb-2">
            Bienvenido, {usuario?.nombre_completo || 'Técnico'}
          </h1>
          <p className="text-gray-600">
            Aquí está tu resumen de actividad y proyectos activos
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            {error}
          </div>
        )}

        {/* Estadísticas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-12">
          <Card>
            <div className="text-center py-6">
              <p className="text-gray-600 text-sm font-medium mb-2">Propuestas Enviadas</p>
              <p className="text-4xl font-black text-blue-600">{stats.total}</p>
            </div>
          </Card>

          <Card>
            <div className="text-center py-6">
              <p className="text-gray-600 text-sm font-medium mb-2">Proyectos Ganados</p>
              <p className="text-4xl font-black text-green-600">{stats.ganados}</p>
            </div>
          </Card>

          <Card>
            <div className="text-center py-6">
              <p className="text-gray-600 text-sm font-medium mb-2">En Proceso</p>
              <p className="text-4xl font-black text-yellow-600">{stats.enProceso}</p>
            </div>
          </Card>

          <Card>
            <div className="text-center py-6">
              <p className="text-gray-600 text-sm font-medium mb-2">Calificación</p>
              <div className="flex justify-center items-baseline gap-1">
                <p className="text-4xl font-black text-yellow-500">{stats.promedio}</p>
                <span className="text-xl">⭐</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Proyectos Activos */}
        <div>
          <div className="mb-6 flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Mis Proyectos Activos</h2>
              <p className="text-gray-600 text-sm mt-1">
                Últimas propuestas aceptadas
              </p>
            </div>
            <Button onClick={() => router.push('/explorar-tecnico')}>
              Explorar Solicitudes
            </Button>
          </div>

          {proyectos.length === 0 ? (
            <Card>
              <div className="text-center py-12">
                <p className="text-gray-600 mb-4">
                  No tienes proyectos activos en este momento
                </p>
                <Button onClick={() => router.push('/explorar-tecnico')}>
                  Ver Solicitudes Disponibles
                </Button>
              </div>
            </Card>
          ) : (
            <div className="space-y-4">
              {proyectos.map((proyecto) => (
                <Card key={proyecto.id}>
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-gray-900">
                        {proyecto.solicitud?.titulo || 'Proyecto'}
                      </h3>
                      <p className="text-sm text-gray-600 mt-1">
                        {proyecto.solicitud?.descripcion}
                      </p>
                    </div>
                    <Badge
                      variant={
                        proyecto.estado === 'aceptada' ? 'success' : 'info'
                      }
                    >
                      {proyecto.estado === 'aceptada'
                        ? 'Aceptado'
                        : 'Pendiente'}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-gray-600">Tu Propuesta</p>
                      <p className="text-lg font-bold text-green-600">
                        ${proyecto.precio_ofertado?.toLocaleString('es-CL')}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Ubicación</p>
                      <p className="text-lg font-bold text-gray-900">
                        {proyecto.solicitud?.comuna || 'N/A'}
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button size="sm">Ir al Proyecto</Button>
                    <Button size="sm" variant="secondary">
                      Ver Solicitud
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
