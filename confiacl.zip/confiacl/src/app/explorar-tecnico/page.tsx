'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import Navbar from '@/components/Navbar'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Input } from '@/components/ui/Input'
import { TechnicianCard } from '@/components/TechnicianCard'
import { apiCall } from '@/lib/api-client'
import type { User } from '@/types'

interface TecnicoProfile {
  id: string
  email: string
  nombre_completo: string
  rut: string
  rol: 'cliente' | 'tecnico' | 'admin'
  es_admin: boolean
  telefono?: string
  perfiles_tecnicos?: {
    id: string
    biografia: string
    anos_experiencia: number
    foto_perfil_url?: string
    calificacion_promedio: number
    valor_visita: number
    especialidades: string[]
    categoria_id: string
  }[]
}

const CATEGORIAS = [
  'Plomería',
  'Electricidad',
  'Carpintería',
  'Climatización',
  'Pintura',
  'Jardinería',
  'Reparación de Electrodomésticos',
  'Servicio Técnico',
]

export default function ExplorarTecnicos() {
  const router = useRouter()
  const [tecnicos, setTecnicos] = useState<TecnicoProfile[]>([])
  const [filtrados, setFiltrados] = useState<TecnicoProfile[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [categoriaSeleccionada, setCategoriaSeleccionada] = useState<string>('')
  const [busqueda, setBusqueda] = useState('')

  useEffect(() => {
    cargarTecnicos()
  }, [])

  useEffect(() => {
    aplicarFiltros()
  }, [tecnicos, categoriaSeleccionada, busqueda])

  async function cargarTecnicos() {
    try {
      setLoading(true)
      setError(null)

      const response = await apiCall<TecnicoProfile[]>('/api/requests/list?role=tecnico')
      if (!response.success) {
        throw new Error(response.error || 'No se pudieron cargar los técnicos')
      }

      // En un API real, esto estaría en /api/technicians/list
      // Por ahora simulamos con el endpoint de requests
      setTecnicos(response.data || [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }

  function aplicarFiltros() {
    let resultado = [...tecnicos]

    if (categoriaSeleccionada) {
      resultado = resultado.filter((t) =>
        t.perfiles_tecnicos?.[0]?.categoria_id === categoriaSeleccionada
      )
    }

    if (busqueda) {
      resultado = resultado.filter((t) =>
        (t.nombre_completo || '').toLowerCase().includes(busqueda.toLowerCase()) ||
        t.perfiles_tecnicos?.[0]?.especialidades?.some((e) =>
          e.toLowerCase().includes(busqueda.toLowerCase())
        )
      )
    }

    setFiltrados(resultado)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-black text-gray-900 mb-2">
            Encuentra tu Experto
          </h1>
          <p className="text-gray-600">
            Explora nuestros técnicos verificados y selecciona el mejor para tu proyecto
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            {error}
          </div>
        )}

        {/* Filtros */}
        <Card className="mb-8">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">
                Buscar por Nombre o Especialidad
              </label>
              <Input
                placeholder="Ej: Juan, Plomería, Electricidad..."
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-3">
                Categorías
              </label>
              <div className="flex flex-wrap gap-2">
                <Button
                  variant={categoriaSeleccionada === '' ? 'primary' : 'secondary'}
                  onClick={() => setCategoriaSeleccionada('')}
                  size="sm"
                >
                  Todos
                </Button>
                {CATEGORIAS.map((cat) => (
                  <Button
                    key={cat}
                    variant={categoriaSeleccionada === cat ? 'primary' : 'secondary'}
                    onClick={() =>
                      setCategoriaSeleccionada(
                        categoriaSeleccionada === cat ? '' : cat
                      )
                    }
                    size="sm"
                  >
                    {cat}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </Card>

        {/* Resultados */}
        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin">⏳</div>
            <p className="text-gray-600 mt-2">Cargando técnicos...</p>
          </div>
        ) : filtrados.length === 0 ? (
          <Card>
            <div className="text-center py-12">
              <p className="text-gray-600 mb-4">
                No encontramos técnicos que coincidan con tu búsqueda
              </p>
              <Button onClick={() => router.push('/nueva-solicitud-cliente')}>
                Publicar una Solicitud en su lugar
              </Button>
            </div>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtrados.map((tecnico) => {
              const perfil = tecnico.perfiles_tecnicos?.[0]
              return (
                <Link
                  key={tecnico.id}
                  href={`/tecnico/${tecnico.id}`}
                >
                  <a className="block hover:scale-105 transition">
                    <TechnicianCard
                      tecnico={tecnico as unknown as User}
                    />
                  </a>
                </Link>
              )
            })}
          </div>
        )}

        {filtrados.length > 0 && (
          <div className="mt-12 text-center">
            <p className="text-gray-600">
              Encontramos <span className="font-bold">{filtrados.length}</span>{' '}
              {filtrados.length === 1 ? 'técnico' : 'técnicos'} disponibles
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
