'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import { Card } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { JobCard } from '@/components/JobCard'
import { apiCall } from '@/lib/api-client'
import type { Solicitud } from '@/types'

export default function MuroTecnico() {
  const router = useRouter()
  const [solicitudes, setSolicitudes] = useState<Solicitud[]>([])
  const [filtradas, setFiltradas] = useState<Solicitud[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [categoria, setCategoria] = useState('')
  const [busqueda, setBusqueda] = useState('')
  const [modalAbierta, setModalAbierta] = useState(false)
  const [propuestaSeleccionada, setPropuestaSeleccionada] = useState<string | null>(null)
  const [propuestaData, setPropuestaData] = useState({ precio_ofertado: '', mensaje: '' })

  useEffect(() => {
    cargarSolicitudes()
  }, [])

  useEffect(() => {
    aplicarFiltros()
  }, [solicitudes, categoria, busqueda])

  async function cargarSolicitudes() {
    try {
      setLoading(true)
      const response = await apiCall<Solicitud[]>('/api/requests/list?estado=abierta')
      if (!response.success) {
        throw new Error(response.error || 'No se pudieron cargar las solicitudes')
      }

      setSolicitudes(response.data || [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }

  function aplicarFiltros() {
    let resultado = [...solicitudes]

    // Filtro por categoría removido - la BD só tiene categoria_id
    // TODO: Cargar categorías para filtrar por nombre

    if (busqueda) {
      resultado = resultado.filter(
        (s) =>
          s.titulo.toLowerCase().includes(busqueda.toLowerCase()) ||
          s.descripcion?.toLowerCase().includes(busqueda.toLowerCase())
      )
    }

    setFiltradas(resultado)
  }

  async function enviarPropuesta() {
    if (!propuestaSeleccionada || !propuestaData.precio_ofertado || !propuestaData.mensaje) {
      alert('Por favor completa todos los campos')
      return
    }

    try {
      const response = await apiCall('/api/proposals/create', {
        method: 'POST',
        body: JSON.stringify({
          solicitud_id: propuestaSeleccionada,
          precio_ofertado: parseFloat(propuestaData.precio_ofertado),
          mensaje: propuestaData.mensaje,
        })
      })

      if (!response.success) {
        throw new Error(response.error || 'No se pudo enviar la propuesta')
      }

      alert('¡Propuesta enviada con éxito!')
      setModalAbierta(false)
      setPropuestaData({ precio_ofertado: '', mensaje: '' })
      setPropuestaSeleccionada(null)
      await cargarSolicitudes()
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Error al enviar propuesta')
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-6xl mx-auto p-6">
        <div className="mb-12">
          <h1 className="text-4xl font-black text-gray-900 mb-2">
            Muro de Oportunidades
          </h1>
          <p className="text-gray-600">
            Explora todas las solicitudes disponibles y envía tus propuestas
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            {error}
          </div>
        )}

        {/* Filtros */}
        <Card className="mb-8">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">
                Buscar
              </label>
              <Input
                placeholder="Título o descripción..."
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">
                Categoría
              </label>
              <select
                value={categoria}
                onChange={(e) => setCategoria(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Todas las categorías</option>
                <option value="Plomería">Plomería</option>
                <option value="Electricidad">Electricidad</option>
                <option value="Carpintería">Carpintería</option>
              </select>
            </div>
          </div>
        </Card>

        {/* Resultados */}
        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin">⏳</div>
            <p className="text-gray-600 mt-2">Cargando oportunidades...</p>
          </div>
        ) : filtradas.length === 0 ? (
          <Card>
            <div className="text-center py-12">
              <p className="text-gray-600">
                No hay solicitudes que coincidan con tu búsqueda
              </p>
            </div>
          </Card>
        ) : (
          <div className="space-y-4">
            {filtradas.map((solicitud) => (
              <Card key={solicitud.id} className="p-0 overflow-hidden">
                <div className="p-6 flex justify-between items-start">
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-gray-900 mb-2">
                      {solicitud.titulo}
                    </h3>
                    <p className="text-gray-600 text-sm mb-3">
                      {solicitud.descripcion}
                    </p>
                    <div className="flex flex-wrap gap-3">
                      <div>
                        <p className="text-xs text-gray-600">Presupuesto</p>
                        <p className="font-bold text-green-600">
                          ${solicitud.presupuesto_estimado?.toLocaleString('es-CL')}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-600">Ubicación</p>
                        <p className="font-bold text-gray-900">
                          {solicitud.comuna}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-600">Categoría</p>
                        <p className="font-bold text-gray-900">
                          {solicitud.categoria_id}
                        </p>
                      </div>
                    </div>
                  </div>
                  <Button
                    onClick={() => {
                      setPropuestaSeleccionada(solicitud.id)
                      setModalAbierta(true)
                    }}
                    className="ml-4"
                  >
                    Enviar Propuesta
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Modal Propuesta */}
        {modalAbierta && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <Card className="w-full max-w-md">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">Enviar Propuesta</h2>
                <button
                  onClick={() => setModalAbierta(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <Input
                  type="number"
                  label="Tu Presupuesto"
                  placeholder="Monto de tu propuesta"
                  value={propuestaData.precio_ofertado}
                  onChange={(e) =>
                    setPropuestaData({ ...propuestaData, precio_ofertado: e.target.value })
                  }
                />

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    Descripción de tu Propuesta
                  </label>
                  <textarea
                    placeholder="Explica por qué eres la mejor opción..."
                    value={propuestaData.mensaje}
                    onChange={(e) =>
                      setPropuestaData({
                        ...propuestaData,
                        mensaje: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows={4}
                  />
                </div>

                <div className="flex gap-2 justify-end">
                  <Button
                    variant="secondary"
                    onClick={() => setModalAbierta(false)}
                  >
                    Cancelar
                  </Button>
                  <Button onClick={enviarPropuesta}>Enviar Propuesta</Button>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
