'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

export default function PaginaPrueba() {
  const [categorias, setCategorias] = useState<any[]>([])
  const [error, setError] = useState<string | null>(null)
  const [cargando, setCargando] = useState(true)

  useEffect(() => {
    async function testConexion() {
      // Intentamos traer las categorías que insertamos por SQL
      const { data, error } = await supabase
        .from('categorias')
        .select('*')
      
      if (error) {
        setError(error.message)
      } else {
        setCategorias(data || [])
      }
      setCargando(false)
    }

    testConexion()
  }, [])

  return (
    <div className="p-10 font-sans">
      <h1 className="text-3xl font-bold text-blue-600 mb-6">Prueba de Conexión: ConfiaCL</h1>
      
      {cargando && <p className="text-gray-500 animate-pulse">Consultando a Supabase...</p>}

      {error && (
        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-4">
          <p className="text-red-700 font-bold">Error de Conexión:</p>
          <p className="text-red-600">{error}</p>
        </div>
      )}

      {!cargando && !error && (
        <div className="bg-green-50 border-l-4 border-green-500 p-4 mb-6">
          <p className="text-green-700 font-bold">¡Conexión Exitosa!</p>
          <p className="text-green-600">Se leyeron {categorias.length} categorías de la base de datos.</p>
        </div>
      )}

      <div className="grid grid-cols-1 gap-2">
        {categorias.map((cat) => (
          <div key={cat.id} className="p-3 bg-white shadow rounded border border-gray-100">
            <span className="font-mono text-sm text-gray-400">#{cat.id}</span>
            <p className="text-lg font-medium text-gray-800">{cat.nombre}</p>
          </div>
        ))}
      </div>
    </div>
  )
}