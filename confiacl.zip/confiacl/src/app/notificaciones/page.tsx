'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import { Card } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { apiCall } from '@/lib/api-client'
import type { Notification } from '@/types'

export default function Notificaciones() {
  const router = useRouter()
  const [notificaciones, setNotificaciones] = useState<Notification[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    cargarNotificaciones()
  }, [])

  async function cargarNotificaciones() {
    try {
      setLoading(true)
      const response = await apiCall<Notification[]>('/api/notifications/list')
      if (!response.success) {
        if (response.error === 'Unauthorized') {
          router.push('/login')
          return
        }
        throw new Error(response.error || 'No se pudieron cargar las notificaciones')
      }

      setNotificaciones(response.data || [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-2xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-4xl font-black text-gray-900">Notificaciones</h1>
          <p className="text-gray-600 mt-2">
            Mantente actualizado sobre tus solicitudes y propuestas
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            {error}
          </div>
        )}

        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin">⏳</div>
            <p className="text-gray-600 mt-2">Cargando notificaciones...</p>
          </div>
        ) : notificaciones.length === 0 ? (
          <Card>
            <div className="text-center py-12">
              <p className="text-gray-600">No tienes notificaciones nuevas</p>
            </div>
          </Card>
        ) : (
          <div className="space-y-3">
            {notificaciones.map((notif) => (
              <Card
                key={notif.id}
                className={`p-4 ${notif.leida ? 'bg-gray-50' : 'bg-blue-50 border-blue-200'}`}
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <p className="font-bold text-gray-900">{notif.titulo || notif.mensaje}</p>
                      {!notif.leida && (
                        <Badge variant="info">
                          Nuevo
                        </Badge>
                      )}
                    </div>
                    {notif.titulo && <p className="text-sm text-gray-600 mb-1">{notif.mensaje}</p>}
                    <p className="text-xs text-gray-500">
                      {new Date(notif.fecha_creacion).toLocaleDateString('es-CL')}
                    </p>
                  </div>
                  {notif.enlace && (
                    <Button
                      size="sm"
                      onClick={() => router.push(notif.enlace || '#')}
                      className="ml-4"
                    >
                      Ver
                    </Button>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
