'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

export default function PanelAdmin() {
  const [debug, setDebug] = useState<any>(null)
  const [stats, setStats] = useState({ usuarios: 0, tecnicos: 0, solicitudes: 0, monto: 0 })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function cargarAdmin() {
      try {
        const { data: { user } } = await supabase.auth.getUser()
        
        if (!user) {
          setDebug({ id_auth: 'USUARIO NO LOGUEADO' })
          setLoading(false)
          return
        }

        const { data: perfil, error } = await supabase
          .from('usuarios')
          .select('*')
          .eq('id', user.id)
          .single()

        setDebug({
          id_auth: user.id,
          id_tabla: perfil?.id || 'No encontrado',
          es_admin_valor: perfil?.es_admin,
          error_supabase: error?.message || 'Ninguno'
        })

        if (perfil?.es_admin) {
          const { count: u } = await supabase.from('usuarios').select('*', { count: 'exact', head: true })
          const { count: t } = await supabase.from('usuarios').select('*', { count: 'exact', head: true }).eq('rol', 'tecnico')
          const { count: s } = await supabase.from('solicitudes').select('*', { count: 'exact', head: true })
          const { data: p } = await supabase.from('propuestas').select('precio_ofertado').eq('estado', 'aceptada')
          
          setStats({
            usuarios: u || 0,
            tecnicos: t || 0,
            solicitudes: s || 0,
            monto: p?.reduce((acc, curr) => acc + curr.precio_ofertado, 0) || 0
          })
        }
      } catch (e: any) {
        setDebug((prev: any) => ({ ...prev, error_js: e.message }))
      } finally {
        setLoading(false)
      }
    }
    cargarAdmin()
  }, [])

  if (loading) return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center">
      <p className="text-blue-400 font-black animate-pulse text-2xl tracking-widest">INICIANDO PROTOCOLO ADMIN...</p>
    </div>
  )

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-8 font-sans">
      <div className="max-w-5xl mx-auto">
        
        {/* MONITOR DE DEPURACIÓN - AHORA LEGIBLE */}
        <div className="mb-10 p-6 bg-slate-900 border-2 border-blue-500/30 rounded-3xl shadow-2xl">
          <h2 className="text-blue-400 font-black uppercase text-sm mb-4 tracking-widest">Monitor de Seguridad</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm font-mono">
            <p className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-500">Sesión Activa:</span> 
              <span className={debug?.id_auth?.includes('NO') ? 'text-red-400' : 'text-green-400'}>{debug?.id_auth ? 'SI' : 'NO'}</span>
            </p>
            <p className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-500">Rango Admin:</span> 
              <span className="text-yellow-400 font-bold">{String(debug?.es_admin_valor).toUpperCase()}</span>
            </p>
            <div className="md:col-span-2">
              <p className="text-slate-500 mb-1">Status DB:</p>
              <p className="bg-black/50 p-2 rounded text-red-400 break-words">{debug?.error_supabase}</p>
            </div>
          </div>
        </div>

        {debug?.es_admin_valor === true ? (
          <div className="animate-in fade-in duration-700">
            <header className="mb-12">
              <h1 className="text-5xl font-black tracking-tighter mb-2">CONFIA <span className="text-blue-500">ADMIN</span></h1>
              <p className="text-slate-400">Control total de la red de técnicos de Talagante.</p>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
               <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-xl">
                  <p className="text-slate-500 text-xs font-bold uppercase mb-2">Tratos Cerrados</p>
                  <p className="text-3xl font-black text-green-400">${stats.monto.toLocaleString('es-CL')}</p>
               </div>
               <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-xl">
                  <p className="text-slate-500 text-xs font-bold uppercase mb-2">Comunidad</p>
                  <p className="text-3xl font-black">{stats.usuarios}</p>
               </div>
               {/* Puedes clonar estos cuadros para Técnicos y Solicitudes */}
            </div>
          </div>
        ) : (
          <div className="text-center py-20 bg-slate-900 rounded-3xl border-2 border-dashed border-slate-800">
            <span className="text-6xl mb-6 block">🔒</span>
            <h2 className="text-3xl font-black text-white mb-2">Acceso no autorizado</h2>
            <p className="text-slate-400 mb-8 max-w-sm mx-auto">Tu cuenta no tiene privilegios de administración. Si crees que es un error, contacta al soporte.</p>
            <button onClick={() => window.location.href = '/'} className="bg-blue-600 hover:bg-blue-700 text-white font-black px-10 py-4 rounded-2xl transition-all shadow-lg shadow-blue-500/20">
              VOLVER AL INICIO
            </button>
          </div>
        )}
      </div>
    </div>
  )
}