'use client'
import { useState } from 'react'
import { supabase } from '@/lib/supabase'
import { validarRut } from '@/lib/validaciones'
import { useRouter } from 'next/navigation'

export default function RegistroTest() {
  const router = useRouter()
  const [form, setForm] = useState({ email: '', password: '', rut: '', nombre: '', rol: 'cliente' })
  const [estado, setEstado] = useState({ tipo: '', msj: '' })

  const ejecutarIntegracion = async (e: React.FormEvent) => {
    e.preventDefault()
    setEstado({ tipo: 'info', msj: 'Procesando registro...' })

    if (!validarRut(form.rut)) {
      return setEstado({ tipo: 'error', msj: '❌ RUT inválido. Usa formato 12345678-9' })
    }

    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: form.email,
      password: form.password,
    })

    if (authError) return setEstado({ tipo: 'error', msj: `❌ Error Auth: ${authError.message}` })

    if (authData.user) {
      const { error: dbError } = await supabase
        .from('usuarios')
        .insert([
          { 
            id: authData.user.id,
            nombre_completo: form.nombre,
            rut: form.rut,
            telefono: '',
            email: form.email,
            rol: form.rol 
          }
        ])

      if (dbError) return setEstado({ tipo: 'error', msj: `❌ Error DB: ${dbError.message}` })
      
      setEstado({ tipo: 'success', msj: `✅ ¡INTEGRACIÓN EXITOSA! Registrado como ${form.rol.toUpperCase()}. Redirigiendo...` })

      setTimeout(() => {
        if (form.rol === 'tecnico') {
          router.push('/dashboard-tecnico') 
        } else {
          router.push('/nueva-solicitud-cliente')
        }
      }, 2000)
    }
  }

  return (
    <div className="p-10 max-w-md mx-auto font-sans">
      <h1 className="text-2xl font-bold mb-6 text-gray-800">Registro en ConfiaCL</h1>
      <form onSubmit={ejecutarIntegracion} className="space-y-4">
        
        <input type="text" placeholder="Nombre Completo" className="w-full border p-2 rounded" 
          onChange={e => setForm({...form, nombre: e.target.value})} required />
        
        <input type="email" placeholder="Correo electrónico" className="w-full border p-2 rounded" 
          onChange={e => setForm({...form, email: e.target.value})} required />
        
        <input type="password" placeholder="Contraseña" className="w-full border p-2 rounded" 
          onChange={e => setForm({...form, password: e.target.value})} required />
        
        <input type="text" placeholder="RUT (12345678-9)" className="w-full border p-2 rounded" 
          onChange={e => setForm({...form, rut: e.target.value})} required />

        <div className="space-y-2">
          <label className="block text-sm font-bold text-gray-700">¿Qué tipo de usuario eres?</label>
          <select 
            className="w-full border p-2 rounded bg-white"
            value={form.rol}
            onChange={e => setForm({...form, rol: e.target.value})}
          >
            <option value="cliente">Quiero buscar un técnico (Cliente)</option>
            <option value="tecnico">Quiero ofrecer mis servicios (Técnico)</option>
          </select>
        </div>
        
        <button type="submit" className="w-full bg-blue-600 text-white font-bold py-2 rounded hover:bg-blue-700 transition">
          Finalizar Registro
        </button>
      </form>

      {estado.msj && (
        <div className={`mt-6 p-4 rounded text-sm ${estado.tipo === 'error' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
          {estado.msj}
        </div>
      )}
    </div>
  )
}