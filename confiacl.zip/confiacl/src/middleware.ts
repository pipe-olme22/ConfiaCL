// src/middleware.ts
import { NextRequest, NextResponse } from 'next/server'

// Rutas que requieren autenticación y rol específico
const PROTECTED_ROUTES = {
  cliente: [
    '/nueva-solicitud-cliente',
    '/mis-solicitudes-cliente',
    '/solicitud/',
    '/editor-perfil',
  ],
  tecnico: [
    '/dashboard-tecnico',
    '/muro-tecnico',
    '/completar-perfil-tecnico',
    '/tecnico',
  ],
  admin: [
    '/admin',
  ],
}

const PUBLIC_ROUTES = [
  '/',
  '/login',
  '/registro-test',
  '/api/auth/login',
  '/api/auth/logout',
  '/prueba-conexion',
]

export async function middleware(request: NextRequest) {
  const pathname = request.nextUrl.pathname
  const authToken = request.cookies.get('auth_token')?.value

  // Rutas públicas - permitir acceso sin autenticación
  if (PUBLIC_ROUTES.some(route => pathname.startsWith(route))) {
    return NextResponse.next()
  }

  // Rutas protegidas sin token - redirigir a login
  if (!authToken) {
    return NextResponse.redirect(new URL('/login', request.url))
  }

  // TODO: Validar token JWT y rol del usuario
  // Por ahora, permitir acceso si hay token
  // Esto debe mejorarse para validar JWT realmente

  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!_next/static|_next/image|favicon.ico).*)',
  ],
}
