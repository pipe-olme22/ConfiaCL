// Cliente Supabase para uso en servidor (API routes) - con privilegios de admin
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ''
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || ''

// Cliente admin para usar en API routes - necesita SUPABASE_SERVICE_ROLE_KEY en .env.local
export const supabaseAdmin = supabaseServiceKey 
  ? createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    })
  : null

// También exportar el cliente anon para uso client-side (autenticación)
import { createClient as createClientAnon } from '@supabase/supabase-js'

const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''

export const supabaseClient = createClientAnon(supabaseUrl, supabaseAnonKey)

// Helper para verificar que tenemos el admin client
export function requireSupabaseAdmin() {
  if (!supabaseAdmin) {
    throw new Error(
      'SUPABASE_SERVICE_ROLE_KEY no está configurada. ' +
      'Por favor añade SUPABASE_SERVICE_ROLE_KEY a tu .env.local'
    )
  }
  return supabaseAdmin
}
