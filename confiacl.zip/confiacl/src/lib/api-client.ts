// Cliente para consumir las API routes seguras
import { ApiResponse } from '@/types'

const API_BASE = typeof window !== 'undefined' ? window.location.origin : ''

export async function apiCall<T = any>(
  endpoint: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  try {
    // Obtener token de localStorage si existe
    const token = typeof window !== 'undefined' 
      ? localStorage.getItem('auth_token')
      : null

    const headers = {
      'Content-Type': 'application/json',
      ...(token && { 'Authorization': `Bearer ${token}` }),
      ...options.headers,
    }

    const response = await fetch(`/api${endpoint}`, {
      ...options,
      headers,
    })

    // Intenta parsear como JSON
    let data
    try {
      data = await response.json()
    } catch (e) {
      // Si no es JSON, es probablemente un error HTML
      const text = await response.text()
      console.error('Response was not JSON:', text.substring(0, 200))
      return {
        success: false,
        error: 'Error del servidor - respuesta inválida',
      }
    }

    if (!response.ok) {
      return {
        success: false,
        error: data.error || `Error ${response.status}`,
        errors: data.errors,
      }
    }

    return {
      success: true,
      data: data?.data || data,
    }
  } catch (error) {
    console.error('API Error:', error)
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Error de conexión al servidor',
    }
  }
}

export const API = {
  // Auth
  login: (email: string, password: string) =>
    apiCall('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  logout: () =>
    apiCall('/auth/logout', {
      method: 'POST',
    }),

  getMe: () =>
    apiCall('/auth/me', {
      method: 'GET',
    }),

  // Solicitudes
  createSolicitud: (data: any) =>
    apiCall('/requests/create', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getSolicitudes: (filters?: any) =>
    apiCall(`/requests/list?${new URLSearchParams(filters || {}).toString()}`, {
      method: 'GET',
    }),

  getSolicitudById: (id: string) =>
    apiCall(`/requests/${id}`, {
      method: 'GET',
    }),

  getMyRequestos: () =>
    apiCall('/requests/my-requests', {
      method: 'GET',
    }),

  // Propuestas
  createPropuesta: (data: any) =>
    apiCall('/proposals/create', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getPropuestas: (solicitudId: string) =>
    apiCall(`/proposals/list?solicitud_id=${solicitudId}`, {
      method: 'GET',
    }),

  acceptPropuesta: (propuestaId: string) =>
    apiCall(`/proposals/${propuestaId}/accept`, {
      method: 'POST',
    }),

  rejectPropuesta: (propuestaId: string) =>
    apiCall(`/proposals/${propuestaId}/reject`, {
      method: 'POST',
    }),

  // Reseñas
  createResena: (data: any) =>
    apiCall('/reviews/create', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getResenas: (tecnicoId: string) =>
    apiCall(`/reviews/list?tecnico_id=${tecnicoId}`, {
      method: 'GET',
    }),

  // Mensajes
  sendMessage: (data: any) =>
    apiCall('/messages/send', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getMessages: (solicitudId: string) =>
    apiCall(`/messages/list?solicitud_id=${solicitudId}`, {
      method: 'GET',
    }),

  // Perfil
  updateProfile: (data: any) =>
    apiCall('/profile/update', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getTecnicoProfile: (tecnicoId: string) =>
    apiCall(`/profile/tecnico/${tecnicoId}`, {
      method: 'GET',
    }),

  // Notificaciones
  getNotifications: () =>
    apiCall('/notifications/list', {
      method: 'GET',
    }),

  markNotificationAsRead: (notificationId: string) =>
    apiCall(`/notifications/${notificationId}/read`, {
      method: 'POST',
    }),
}
