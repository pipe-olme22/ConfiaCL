// src/lib/validaciones.ts

export interface ValidationError {
  field: string
  message: string
}

export function validarRut(rut: string): boolean {
  // Limpia puntos y guiones para la lógica, pero espera formato 12345678-9
  if (!/^[0-9]+-[0-9kK]{1}$/.test(rut)) return false;
  
  const [numero, dv] = rut.split('-');
  let suma = 0;
  let multiplo = 2;
  
  for (let i = numero.length - 1; i >= 0; i--) {
    suma += multiplo * parseInt(numero.charAt(i));
    multiplo = multiplo < 7 ? multiplo + 1 : 2;
  }
  
  const dvEsperado = 11 - (suma % 11);
  const dvFinal = dvEsperado === 11 ? '0' : dvEsperado === 10 ? 'K' : dvEsperado.toString();
  
  return dvFinal.toUpperCase() === dv.toUpperCase();
}

export function validarEmail(email: string): boolean {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
}

export function validarPassword(password: string): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (password.length < 8) {
    errors.push('La contraseña debe tener al menos 8 caracteres');
  }
  if (!/[A-Z]/.test(password)) {
    errors.push('Debe contener al menos una mayúscula');
  }
  if (!/[a-z]/.test(password)) {
    errors.push('Debe contener al menos una minúscula');
  }
  if (!/[0-9]/.test(password)) {
    errors.push('Debe contener al menos un número');
  }
  
  return {
    valid: errors.length === 0,
    errors,
  };
}

export function validarNombres(nombres: string): boolean {
  return nombres.trim().length >= 3 && !/[^a-záéíóúñ\s]/i.test(nombres);
}

export function validarPresupuesto(min?: number, max?: number): boolean {
  if (min && min < 0) return false;
  if (max && max < 0) return false;
  if (min && max && min > max) return false;
  return true;
}

export function validarTelefono(telefono: string): boolean {
  return /^[0-9\s\-\+]{8,}$/.test(telefono);
}

export function sanitizeString(str: string): string {
  return str.trim().replace(/[<>]/g, '');
}

export function sanitizeUrl(url: string): string {
  try {
    new URL(url);
    return url;
  } catch {
    return '';
  }
}

export function validarCategoria(categoria: string, categoriasValidas: string[]): boolean {
  return categoriasValidas.includes(categoria);
}

export function validarCalificacion(calificacion: number): boolean {
  return calificacion >= 1 && calificacion <= 5 && Number.isInteger(calificacion);
}