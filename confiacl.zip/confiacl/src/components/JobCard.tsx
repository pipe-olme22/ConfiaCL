// src/components/JobCard.tsx
import React from 'react'
import Link from 'next/link'
import { Card, Badge } from '@/components/ui'
import type { Solicitud } from '@/types'

interface JobCardProps {
  solicitud: Solicitud
  showStatus?: boolean
  clickable?: boolean
}

export const JobCard: React.FC<JobCardProps> = ({
  solicitud,
  showStatus = true,
  clickable = true,
}) => {
  const presupuesto = solicitud.presupuesto_estimado
    ? `$${solicitud.presupuesto_estimado?.toLocaleString('es-CL')}`
    : 'Presupuesto negociable'

  const content = (
    <div className="p-6">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-grow">
          <h3 className="text-lg font-black text-gray-900 mb-2 leading-tight">{solicitud.titulo}</h3>
          <p className="text-gray-600 text-sm line-clamp-2">{solicitud.descripcion}</p>
        </div>
        {showStatus && (
          <Badge
            variant={solicitud.estado === 'abierta' ? 'success' : 'default'}
            className="ml-2 flex-shrink-0"
          >
            {solicitud.estado}
          </Badge>
        )}
      </div>

      <div className="flex flex-wrap gap-3 pt-4 border-t border-gray-100">
        <div>
          <p className="text-xs text-gray-500 uppercase font-bold mb-1">Presupuesto</p>
          <p className="text-sm font-bold text-gray-900">{presupuesto}</p>
        </div>

        <div>
          <p className="text-xs text-gray-500 uppercase font-bold mb-1">Comuna</p>
          <p className="text-sm font-bold text-gray-900">📍 {solicitud.comuna}</p>
        </div>
      </div>
    </div>
  )

  if (!clickable) {
    return <Card>{content}</Card>
  }

  return (
    <Link href={`/solicitud/${solicitud.id}`}>
      <Card hoverable clickable>
        {content}
      </Card>
    </Link>
  )
}
