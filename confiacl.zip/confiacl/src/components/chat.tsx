'use client'
import { useEffect, useState, useRef } from 'react'
import { supabase } from '@/lib/supabase'

export default function Chat({ solicitudId, usuarioId }: { solicitudId: string, usuarioId: string }) {
  const [mensajes, setMensajes] = useState<any[]>([])
  const [nuevoMensaje, setNuevoMensaje] = useState('')
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // 1. Cargar mensajes iniciales
    const cargarMensajes = async () => {
      const { data } = await supabase
        .from('mensajes')
        .select('*')
        .eq('solicitud_id', solicitudId)
        .order('fecha_creacion', { ascending: true })
      if (data) setMensajes(data)
    }
    cargarMensajes()

    // 2. Escuchar mensajes nuevos en tiempo real
    const canal = supabase
      .channel(`chat-${solicitudId}`)
      .on('postgres_changes', { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'mensajes', 
        filter: `solicitud_id=eq.${solicitudId}` 
      }, (payload) => {
        setMensajes(prev => [...prev, payload.new])
      })
      .subscribe()

    return () => { supabase.removeChannel(canal) }
  }, [solicitudId])

  // Auto-scroll al último mensaje
  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [mensajes])

  const enviarMensaje = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!nuevoMensaje.trim()) return

    const { error } = await supabase.from('mensajes').insert([{
      solicitud_id: solicitudId,
      emisor_id: usuarioId,
      contenido: nuevoMensaje
    }])

    if (!error) setNuevoMensaje('')
  }

  return (
    <div className="flex flex-col h-[400px] bg-white rounded-3xl border border-gray-100 shadow-inner overflow-hidden">
      {/* AREA DE MENSAJES */}
      <div className="flex-grow p-6 overflow-y-auto space-y-4 bg-gray-50/50">
        {mensajes.map((m) => (
          <div key={m.id} className={`flex ${m.emisor_id === usuarioId ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[70%] p-3 rounded-2xl text-sm shadow-sm ${
              m.emisor_id === usuarioId 
                ? 'bg-blue-600 text-white rounded-tr-none' 
                : 'bg-white text-gray-800 rounded-tl-none border border-gray-100'
            }`}>
              {m.contenido}
            </div>
          </div>
        ))}
        <div ref={scrollRef} />
      </div>

      {/* INPUT */}
      <form onSubmit={enviarMensaje} className="p-4 bg-white border-t border-gray-100 flex gap-2">
        <input 
          type="text" 
          placeholder="Escribe un mensaje..."
          className="flex-grow p-3 rounded-xl bg-gray-50 outline-none focus:ring-2 focus:ring-blue-500 text-sm"
          value={nuevoMensaje}
          onChange={(e) => setNuevoMensaje(e.target.value)}
        />
        <button className="bg-blue-600 text-white p-3 rounded-xl hover:bg-blue-700 transition">
          🚀
        </button>
      </form>
    </div>
  )
}