// src/components/TechnicianCard.tsx
import React from 'react'
import Link from 'next/link'
import { Card, Badge } from '@/components/ui'
import type { User } from '@/types'

interface TechnicianCardProps {
  tecnico: User & {
    rating_promedio?: number
    total_resenas?: number
    especialidades?: string[]
    valor_visita?: number
  }
  clickable?: boolean
}

export const TechnicianCard: React.FC<TechnicianCardProps> = ({
  tecnico,
  clickable = true,
}) => {
  const renderRating = (rating?: number) => {
    if (!rating) return null
    const stars = Math.round(rating)
    return (
      <div className="flex items-center gap-2">
        <span>
          {'⭐'.repeat(stars)}
          {'☆'.repeat(5 - stars)}
        </span>
        <span className="text-xs text-gray-600">
          ({rating.toFixed(1)}) {tecnico.total_resenas || 0} reseñas
        </span>
      </div>
    )
  }

  const content = (
    <div className="p-6">
      {/* Avatar y nombre */}
      <div className="flex items-start gap-4 mb-4">
        <div className="w-16 h-16 bg-gradient-to-br from-blue-200 to-blue-300 rounded-2xl flex items-center justify-center text-2xl font-bold text-blue-700 flex-shrink-0">
          {tecnico.nombre_completo?.charAt(0).toUpperCase() || 'T'}
        </div>
        <div className="flex-grow">
          <h3 className="text-lg font-black text-gray-900">{tecnico.nombre_completo}</h3>
          {renderRating(tecnico.rating_promedio)}
        </div>
      </div>

      {/* Especialidades */}
      {tecnico.especialidades && tecnico.especialidades.length > 0 && (
        <div className="mb-4 pb-4 border-b border-gray-100">
          <p className="text-xs text-gray-500 uppercase font-bold mb-2">Especialidades</p>
          <div className="flex flex-wrap gap-2">
            {tecnico.especialidades.slice(0, 3).map((esp, idx) => (
              <Badge key={idx} variant="info" className="text-xs">
                {esp}
              </Badge>
            ))}
            {tecnico.especialidades.length > 3 && (
              <Badge variant="info" className="text-xs">
                +{tecnico.especialidades.length - 3}
              </Badge>
            )}
          </div>
        </div>
      )}

      {/* Valor visita */}
      {tecnico.valor_visita && (
        <div className="py-4 border-t border-gray-100">
          <p className="text-xs text-gray-500 uppercase font-bold mb-1">Costo Visita</p>
          <p className="text-lg font-black text-green-600">
            ${tecnico.valor_visita?.toLocaleString('es-CL')} CLP
          </p>
        </div>
      )}
    </div>
  )

  if (!clickable) {
    return <Card>{content}</Card>
  }

  return (
    <Link href={`/tecnico/${tecnico.id}`}>
      <Card hoverable clickable>
        {content}
      </Card>
    </Link>
  )
}
