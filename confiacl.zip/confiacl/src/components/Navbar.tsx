'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter, usePathname } from 'next/navigation'
import { API } from '@/lib/api-client'
import type { User } from '@/types'

interface NotificationBadge {
  noLeidas: number
  isLoading: boolean
}

export default function Navbar() {
  const [user, setUser] = useState<User | null>(null)
  const [notificaciones, setNotificaciones] = useState<NotificationBadge>({
    noLeidas: 0,
    isLoading: true,
  })
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const pathname = usePathname()

  // Cargar usuario y notificaciones
  useEffect(() => {
    const loadData = async () => {
      // Verificar si tiene token
      const token = typeof window !== 'undefined' 
        ? localStorage.getItem('auth_token')
        : null

      if (!token) {
        setIsLoading(false)
        return
      }

      const userResult = await API.getMe()

      if (userResult.success) {
        const userData = userResult.data as User
        setUser(userData)

        // Cargar notificaciones
        const notifsResult = await API.getNotifications()
        if (notifsResult.success) {
          const data = notifsResult.data as any[]
          const unreadCount = data?.filter(n => !n.leido).length || 0
          setNotificaciones({
            noLeidas: unreadCount,
            isLoading: false,
          })
        }
      } else {
        // Token inválido
        localStorage.removeItem('auth_token')
      }

      setIsLoading(false)
    }

    loadData()
  }, [])

  const handleLogout = async () => {
    await API.logout()
    localStorage.removeItem('auth_token')
    setUser(null)
    setIsDropdownOpen(false)
    router.push('/login')
  }

  const isActive = (path: string) => pathname?.startsWith(path)

  // Rutas de navegación según rol
  const getNavLinks = () => {
    if (!user) return []

    if (user.rol === 'tecnico') {
      return [
        { label: 'Dashboard', href: '/dashboard-tecnico', icon: '📊' },
        { label: 'Oportunidades', href: '/muro-tecnico', icon: '🎯' },
        { label: 'Mi Perfil', href: '/editor-perfil', icon: '👤' },
      ]
    }

    if (user.es_admin) {
      return [
        { label: 'Dashboard', href: '/admin', icon: '📊' },
      ]
    }

    return [
      { label: 'Nueva Solicitud', href: '/nueva-solicitud-cliente', icon: '✨' },
      { label: 'Mis Solicitudes', href: '/mis-solicitudes-cliente', icon: '📋' },
      { label: 'Explorar Técnicos', href: '/explorar-tecnico', icon: '🔍' },
    ]
  }

  return (
    <nav className="bg-white border-b border-gray-100 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 flex-shrink-0 group">
            <div className="text-2xl font-black tracking-tighter text-blue-600 group-hover:scale-105 transition">
              CONFIA<span className="text-gray-900">CL</span>
            </div>
          </Link>

          {/* Central Navigation - Desktop */}
          {user && (
            <div className="hidden md:flex items-center gap-1">
              {getNavLinks().map(link => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                    isActive(link.href)
                      ? 'bg-blue-50 text-blue-600'
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <span className="mr-2">{link.icon}</span>
                  {link.label}
                </Link>
              ))}
            </div>
          )}

          {/* Right Actions */}
          <div className="flex items-center gap-4">
            {user ? (
              <>
                {/* Notifications */}
                <Link
                  href="/notificaciones"
                  className="relative p-2 text-gray-600 hover:bg-gray-100 rounded-xl transition group"
                >
                  <span className="text-xl">🔔</span>
                  {notificaciones.noLeidas > 0 && (
                    <span className="absolute top-0 right-0 flex items-center justify-center h-5 w-5 bg-red-500 text-white text-xs font-bold rounded-full animate-pulse group-hover:animate-none">
                      {notificaciones.noLeidas > 9 ? '9+' : notificaciones.noLeidas}
                    </span>
                  )}
                </Link>

                {/* Profile Dropdown */}
                <div className="relative">
                  <button
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    className="flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-gray-100 transition group"
                  >
                    <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center text-white text-sm font-bold">
                      {user.nombre_completo?.charAt(0).toUpperCase() || 'U'}
                    </div>
                    <span className="hidden sm:inline text-sm font-bold text-gray-900 group-hover:text-blue-600">
                      {user.nombre_completo?.split(' ')[0]}
                    </span>
                    <svg
                      className={`w-4 h-4 text-gray-600 transition-transform ${
                        isDropdownOpen ? 'rotate-180' : ''
                      }`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                    </svg>
                  </button>

                  {/* Dropdown Menu */}
                  {isDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden z-50">
                      <Link
                        href="/editor-perfil"
                        className="block px-4 py-3 hover:bg-gray-50 text-gray-700 font-bold transition"
                        onClick={() => setIsDropdownOpen(false)}
                      >
                        👤 Mi Perfil
                      </Link>
                      <hr className="border-gray-100" />
                      <button
                        onClick={handleLogout}
                        className="w-full text-left px-4 py-3 hover:bg-red-50 text-red-600 font-bold transition"
                      >
                        🚪 Cerrar Sesión
                      </button>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <>
                <Link
                  href="/login"
                  className="hidden sm:inline px-4 py-2 font-bold text-gray-700 hover:text-blue-600 transition"
                >
                  Entrar
                </Link>
                <Link
                  href="/registro-test"
                  className="px-4 py-2 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-200 transition"
                >
                  Registrarse
                </Link>
              </>
            )}
          </div>
        </div>

        {/* Mobile Navigation */}
        {user && (
          <div className="md:hidden pb-4 border-t border-gray-100 flex gap-2 overflow-x-auto">
            {getNavLinks().map(link => (
              <Link
                key={link.href}
                href={link.href}
                className={`px-4 py-2 rounded-xl text-sm font-bold whitespace-nowrap transition-all flex-shrink-0 ${
                  isActive(link.href)
                    ? 'bg-blue-50 text-blue-600'
                    : 'bg-gray-50 text-gray-600'
                }`}
              >
                <span className="mr-1">{link.icon}</span>
                {link.label}
              </Link>
            ))}
          </div>
        )}
      </div>
    </nav>
  )
}