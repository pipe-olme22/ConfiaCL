// src/components/ReviewCard.tsx
import React from 'react'
import { Card, Badge } from '@/components/ui'
import type { Resena } from '@/types'

interface ReviewCardProps {
  resena: Resena
  clienteNombre?: string
}

export const ReviewCard: React.FC<ReviewCardProps> = ({
  resena,
  clienteNombre = 'Cliente Verificado',
}) => {
  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center gap-1">
        <span>
          {'⭐'.repeat(rating)}
          {'☆'.repeat(5 - rating)}
        </span>
        <span className="text-sm font-black text-gray-900">{rating}/5</span>
      </div>
    )
  }

  return (
    <Card className="p-6">
      <div className="flex items-start justify-between mb-3">
        <div>
          <p className="font-black text-gray-900">{clienteNombre}</p>
          <p className="text-xs text-gray-500">
            {new Date(resena.fecha_creacion).toLocaleDateString('es-CL', {
              year: 'numeric',
              month: 'long',
              day: 'numeric',
            })}
          </p>
        </div>
        <Badge variant="success">✓ Verificado</Badge>
      </div>

      <div className="mb-3">
        {renderStars(resena.puntuacion)}
      </div>

      <p className="text-gray-700 text-sm leading-relaxed">{resena.comentario}</p>
    </Card>
  )
}
