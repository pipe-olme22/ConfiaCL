'use client'
import { useState } from 'react'
import { supabase } from '@/lib/supabase'

export default function FormularioResena({ solicitud, onFinish }: { solicitud: any, onFinish: () => void }) {
  const [puntuacion, setPuntuacion] = useState(5)
  const [comentario, setComentario] = useState('')
  const [loading, setLoading] = useState(false)

  const enviarResena = async () => {
    setLoading(true)
    try {
      // 1. Insertar la reseña
      const { error: errResena } = await supabase.from('resenas').insert([{
        solicitud_id: solicitud.id,
        cliente_id: solicitud.cliente_id,
        tecnico_id: solicitud.propuestas.find((p: any) => p.estado === 'aceptada').tecnico_id,
        puntuacion,
        comentario
      }])
      if (errResena) throw errResena

      // 2. Cambiar estado de la solicitud a 'finalizada'
      await supabase.from('solicitudes').update({ estado: 'finalizada' }).eq('id', solicitud.id)

      alert("¡Gracias por tu calificación!")
      onFinish()
    } catch (e: any) {
      alert("Error: " + e.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-white p-6 rounded-3xl border-2 border-blue-500 mt-4 shadow-xl">
      <h3 className="font-black text-lg mb-4 text-gray-800">Califica el servicio</h3>
      <div className="flex gap-2 mb-4 text-2xl">
        {[1, 2, 3, 4, 5].map(num => (
          <button 
            key={num} 
            onClick={() => setPuntuacion(num)}
            className={num <= puntuacion ? 'text-yellow-400' : 'text-gray-300'}
          >
            ★
          </button>
        ))}
      </div>
      <textarea 
        className="w-full border p-3 rounded-xl bg-gray-50 mb-4 outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Cuéntanos cómo fue tu experiencia..."
        onChange={(e) => setComentario(e.target.value)}
      />
      <button 
        onClick={enviarResena}
        disabled={loading}
        className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl hover:bg-blue-700 transition"
      >
        {loading ? 'Procesando...' : 'Finalizar y Calificar'}
      </button>
    </div>
  )
}