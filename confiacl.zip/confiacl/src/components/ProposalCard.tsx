// src/components/ProposalCard.tsx
import React from 'react'
import { Card, Badge, Button } from '@/components/ui'
import type { Propuesta } from '@/types'

interface ProposalCardProps {
  propuesta: Propuesta
  onAccept?: (id: string) => void
  onReject?: (id: string) => void
  isOwner?: boolean
  isLoading?: boolean
}

export const ProposalCard: React.FC<ProposalCardProps> = ({
  propuesta,
  onAccept,
  onReject,
  isOwner = false,
  isLoading = false,
}) => {
  return (
    <Card className="p-6">
      {/* Header */}
      <div className="flex items-start justify-between mb-4 pb-4 border-b border-gray-100">
        <div>
          <h3 className="text-lg font-black text-gray-900 mb-1">
            {propuesta.tecnico?.nombre_completo || 'Tecnico'}
          </h3>
          <p className="text-xs text-gray-500 font-medium">
            Propuesta hecha {new Date(propuesta.fecha_creacion || '').toLocaleDateString('es-CL')}
          </p>
        </div>
        <Badge
          variant={
            propuesta.estado === 'aceptada'
              ? 'success'
              : propuesta.estado === 'rechazada'
              ? 'danger'
              : 'info'
          }
        >
          {propuesta.estado}
        </Badge>
      </div>

      {/* Precio destacado */}
      <div className="mb-4 p-4 bg-blue-50 rounded-2xl border border-blue-100">
        <p className="text-xs text-blue-600 uppercase font-bold mb-1">Presupuesto Propuesto</p>
        <p className="text-3xl font-black text-blue-900">
          ${propuesta.precio_ofertado?.toLocaleString('es-CL')} CLP
        </p>
      </div>

      {/* Mensaje */}
      <div className="mb-4">
        <p className="text-xs text-gray-500 uppercase font-bold mb-2">Propuesta</p>
        <p className="text-gray-700 text-sm leading-relaxed">{propuesta.mensaje}</p>
      </div>

      {/* Acciones */}
      {isOwner && propuesta.estado === 'pendiente' && (
        <div className="flex gap-3 pt-4 border-t border-gray-100">
          <Button
            variant="primary"
            size="md"
            onClick={() => onAccept?.(propuesta.id)}
            disabled={isLoading}
            isLoading={isLoading}
            className="flex-1"
          >
            ✓ Aceptar Propuesta
          </Button>
          <Button
            variant="secondary"
            size="md"
            onClick={() => onReject?.(propuesta.id)}
            disabled={isLoading}
            className="flex-1"
          >
            ✕ Rechazar
          </Button>
        </div>
      )}

      {/* Estado final */}
      {propuesta.estado !== 'pendiente' && (
        <div className="pt-4 border-t border-gray-100">
          <p className="text-xs text-gray-500 uppercase font-bold mb-2">Estado</p>
          <div className="flex items-center gap-2">
            {propuesta.estado === 'aceptada' ? (
              <>
                <span className="text-green-600 text-xl">✓</span>
                <span className="text-green-600 font-bold">Esta propuesta fue aceptada</span>
              </>
            ) : (
              <>
                <span className="text-red-600 text-xl">✕</span>
                <span className="text-red-600 font-bold">Esta propuesta fue rechazada</span>
              </>
            )}
          </div>
        </div>
      )}
    </Card>
  )
}
